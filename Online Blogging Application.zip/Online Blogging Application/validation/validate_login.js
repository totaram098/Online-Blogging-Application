	function validate_login(){
		var is_valid = true;

		var email_pattern = /[a-z]{1,}[0-9]*@[a-z]{1,}[.][a-z]{1,}/;


		var email = document.querySelector("input[name=email]").value;
		var password = document.querySelector("input[name=password]").value;


		var email_msg = document.querySelector("#email_msg");
		var password_msg = document.querySelector("#password_msg");

		if (email=="" || email==" ") {
			is_valid = false;
			email_msg.innerHTML = "This Field is required";
		}
		else{
			email_msg.innerHTML = "";
			if (!(email_pattern.test(email))) {
				is_valid = false;
				email_msg.innerHTML = "Email must be like example123@gmail.com";
			}
		}

		if (password=="" || password==" ") {
			is_valid = false;
			password_msg.innerHTML = "This Field is required";
			$password_matched = false;
		}else{
			password_msg.innerHTML = "";
		}


		return is_valid;
	}
