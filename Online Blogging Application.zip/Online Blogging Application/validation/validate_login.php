<?php
	function validate_login(){
		global $_POST;
		extract($_POST);
		$is_valid = true;

		$email_pattern = "/[a-z]{1,}[0-9]*@[a-z]{1,}[.][a-z]{1,}/";

		$_SESSION['message'] = array();


		if ($email=="" || $email==" ") {
			$is_valid = false;
			$_SESSION['message']["email_msg"] = "This Field is required";
		}
		else{
			if(!(preg_match($email_pattern, $email))) {
				$is_valid = false;
				$_SESSION['message']["email_msg"] = "Email must be like example123@gmail.com";
			}
		}


		if ($password=="" || $password==" ") {
			$is_valid = false;
			$password_matched = false;
			$_SESSION['message']["password_msg"] = "This Field is required";
		}

		return $is_valid;
	}
?>