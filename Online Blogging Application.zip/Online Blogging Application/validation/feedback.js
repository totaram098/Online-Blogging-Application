	function validate_feedback(){
		var is_valid = true;

		var name_pattern = /^[A-Z]{1}[a-z\s]{2,}/;
		var email_pattern = /[a-z]{1,}[0-9]*@[a-z]{1,}[.][a-z]{1,}/;


		var user_name = document.querySelector("input[name=user_name]").value;
		var user_email = document.querySelector("input[name=user_email]").value;
		var feedback = document.querySelector("textarea[name=feedback]").value;


		var user_name_msg = document.querySelector("#user_name_msg");
		var user_email_msg = document.querySelector("#user_email_msg");
		var feedback_msg = document.querySelector("#feedback_msg");



		if (user_name=="" || user_name==" ") {
			is_valid = false;
			user_name_msg.innerHTML = "This Field is required";
		}
		else{
			user_name_msg.innerHTML = "";
			if (!(name_pattern.test(user_name))) {
				is_valid = false;
				user_name_msg.innerHTML = "First Character must be Capital and other small.";
			}
		}

		

		if (user_email=="" || user_email==" ") {
			is_valid = false;
			user_email_msg.innerHTML = "This Field is required";
		}
		else{
			user_email_msg.innerHTML = "";
			if (!(email_pattern.test(user_email))) {
				is_valid = false;
				user_email_msg.innerHTML = "Email must be like example123@gmail.com";
			}
		}

		if (feedback=="" || feedback==" ") {
			is_valid = false;
			feedback_msg.innerHTML = "This Field is required";
		}
		else{
			feedback_msg.innerHTML = "";
		}

		return is_valid;
	}
