<?php
	function validate_password($validate = ""){
		global $_POST;
		extract($_POST);
		$is_valid = true;
		$password_matched = true;
		$user_password = unserialize($_COOKIE['user_data']);
		$user_password = $user_password['password'];
		$password_alphabetical_pattern = "/[a-z]{1}/";
		$password_capital_pattern = "/[A-Z]{1}/";
		$password_numeric_pattern = "/[0-9]{1}/";

		$_SESSION['message'] = array();

		if ($user_password != $old_password) {
			$is_valid = false;
			$_SESSION['message']["old_password_msg"] = "Invalid Password";
		}
	
		if (!$old_password) {
			$is_valid = false;
			$_SESSION['message']["old_password_msg"] = "This Field is required";
		}



		if (!$new_password) {
			$is_valid = false;
			$password_matched = false;
			$_SESSION['message']["new_password_msg"] = "This Field is required";
		}
		else{
			$is_correct_password = true;
			if(!(strlen($new_password) > 7 )){
				$is_correct_password = false;
			}
			else if(!(preg_match($password_alphabetical_pattern,$new_password))){
				$is_correct_password = false;
			}
			else if(!(preg_match($password_numeric_pattern,$new_password))){
				$is_correct_password = false;
			}
			else if(!(preg_match($password_capital_pattern,$new_password))){
				$is_correct_password = false;
			}

			if(!$is_correct_password){
				$_SESSION['message']["new_password_msg"] = "Password Must Contain at Least 8 Characters, Capital, Small and Numeric Characters.";
			}
		}

		if (!$confirm_password) {
			$is_valid = false;
			$password_matched = false;
			$_SESSION['message']["confirm_password_msg"] =  "This Field is required";
		}
		if ($confirm_password != $new_password && $password_matched) {
			$is_valid = false;
			$_SESSION['message']["confirm_password_msg"] = "Doesn`t Match Password";
		}



		return $is_valid;
	}
?>