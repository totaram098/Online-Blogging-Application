<?php
	function validate_feedback(&$messages){
		global $_REQUEST;
		extract($_REQUEST);
		$is_valid = true;

		$name_pattern = "/^[A-Z]{1}[a-z\s]{2,}/";
		$user_email_pattern = "/[a-z]{1,}[0-9]*@[a-z]{1,}[.][a-z]{1,}/";

		if ($user_name=="") {
			$is_valid = false;
			$messages["Full Name"] = "This Field is required";
		}
		else{
			if (!(preg_match($name_pattern, $user_name))) {
				$is_valid = false;
				$messages["Full Name"] = "First Character must be Capital and other small.";
			}
		}

		if ($user_email=="" || $user_email==" ") {
			$is_valid = false;
			$messages["Email"] = "This Field is required";
		}
		else{
			if(!(preg_match($user_email_pattern, $user_email))) {
				$is_valid = false;
				$messages["Email"] = "Email must be like example123@gmail.com";
			}
		}

		if ($feedback=="" || $feedback==" ") {
			$is_valid = false;
			$messages["Feeback Messsage"] = "This Field is required";
		}

		return $is_valid;
	}
?>