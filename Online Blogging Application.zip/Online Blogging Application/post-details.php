<?php 
	include("assets/user/user-header.php");
?>
	<!-- content -->
	<div class="container-fluid my-5">
		<?php 
			if (!(isset($_GET['id']) && $_GET['id'])) {
			?>
			<script>
				window.location.href = "index.php";
			</script>
			<?php

			} 
			if (!isset($_GET['post_details'])) {
			?>
			<script>
				window.location.href = "index.php";
			</script>
			<?php

			}

			$user_id = $user_data['user_id'];
			$settings = array();
			$is_active = false;
			$is_theme_set = "no";
			$setting_query = "SELECT * FROM setting WHERE user_id = {$user_id}";
			$setting_result = $database->execute_query($setting_query);
			if ($setting_result->num_rows > 0) {
				while($theme_setting = mysqli_fetch_assoc($setting_result)){
					$key = $theme_setting['setting_key'];
					$value = $theme_setting['setting_value'];
					$settings[$key] = $value;
					$is_active = ($theme_setting['setting_status'] == "Active")? true : false;
				}
				$is_theme_set = "yes";
			}

			if ($is_theme_set == "yes" && $is_active) {
				$title_color = $settings['title_color'];
				$title_font_style = $settings['title_font_style'];
				$title_bg_color = $settings['title_background_color'];
				$title_font_size = $settings["title_font_size"];

				$description_color = $settings["description_color"];
				$description_font_style = $settings["description_font_style"];
				$description_bg_color = $settings["description_background_color"];
				$description_font_size = $settings["description_font_size"];
			}

			$post_id = $_GET['id'];
			$query = "SELECT p.*,b.blog_title,b.user_id blog_creator,u.first_name,u.last_name,u.user_image,COUNT(fb.follow_id) follower FROM post p JOIN blog b USING(blog_id) 
				JOIN USER u USING(user_id) 
				LEFT JOIN following_blog fb ON fb.blog_following_id = b.blog_id 
				WHERE p.post_id = '{$post_id}'";
			$result = $database->execute_query($query);
			if ($result->num_rows > 0) {
					extract(mysqli_fetch_assoc($result));
			


		?>
		<style>
			.post_title{
				color:<?= $title_color??"" ?>;
				font-style: <?= $title_font_style??"" ?>;
				font-weight: <?= $title_font_style??"" ?>;
				font-size:<?= isset($title_font_size)?$title_font_size."px":"" ?>;
				background-color:<?= $title_bg_color ??"" ?>;
			}
			.post_description{
				color:<?= $description_color??"" ?>;
				font-style: <?= $description_font_style??"" ?>;
				font-weight: <?= $description_font_style??"" ?>;
				font-size:<?= isset($description_font_size)?$description_font_size."px":"" ?>;
				background-color:<?= $description_bg_color ??"" ?>;
			}
		</style>
		<div class="row">
			<div class="col-md-8">
				<!-- post details -->
				<div class="card border border-0">
				  <div class="p-md-2">
				  	<img src="uploads/post-images/<?= $featured_image?>" class="shadow rounded card-img-top " alt="..." >
				  </div>
				  	<?php 
			  			$follower_id = $user_data["user_id"];
			  			$follow_query = "SELECT * FROM following_blog WHERE 
			  			follower_id = {$follower_id} AND blog_following_id = {$blog_id}";
			  			$follow_result = $database->execute_query($follow_query);
			  			$follow = "Follow";
			  			if ($follow_result->num_rows > 0) {
				  			$follow = "Unfollow";
			  			}
				  	?>
				  	<a href="blog-details.php?id=<?= $blog_id ?>&blog_details" class="text-decoration-none text-dark">
				  	<span class="mx-md-3 m-2 mt-2 badge text-bg-primary px-2 position-absolute">Blog</span>
				  	<h2 class="border-start border-3 d-flex justify-content-between shadow mx-md-2 rounded p-3 my-3 py-3">
						<span><?= $blog_title ?></span> 
						<?php if ($blog_creator != $user_data['user_id']): ?>
							<a style="cursor:pointer;" onclick="follow_blog(<?= $blog_id ?>,<?= $follower_id ?>,'<?= $follow ?>')" class="btn border btn-primary">
								<span id="is_follow"><?= $follow; ?></span> 
								<span class="badge text-bg-warning" id="followers"><?= $follower ?></span>
							</a>
						<?php endif ?>
					</h2>
					</a>
					<!-- <div class="border"></div> -->
				  	<div class="card-body shadow m-md-2 rounded">
					    <h2 class="card-title border-start border-3 px-2 post_title"><?= $post_title ?></h2>
					    <span class="border-start border-3 px-2 text-secondary lead" style="font-size: 15px;">
					    	<i>Post Date : <?=  date("d M Y  H:i:s A",strtotime($created_at))  ?></i>
					    </span>
					    <h5 class="border-start mt-2 border-3 px-2 text-secondary lead mb-3" style="font-size: 15px;">
					    	<i><img src="uploads/profile-images/<?= $user_image ?>" alt="" class="rounded-circle" style="width: 40px;height: 40px;"> <?= $first_name." ".$last_name ?></i>
					    </h5>
					    <h4 class="border-start px-2 mt-2 border-3">Post Summary</h4>
					    <p class="card-text post_description">
					    	<?= $post_summary ?>
					    </p>
					    <h4 class="border-start px-2 mt-2 border-3">Post Description</h4>
					    <p class="card-text post_description">
					    	<?= $post_description ?>
					    </p>
					    <h6 class="border-start my-3 border-3 px-2 text-secondary lead" style="font-size:18px">Categories</h6>
					    <p class="mb-2">
					    	<?php 
					    		$category_query = "SELECT c.* FROM category c JOIN post_category pc USING(category_id) WHERE pc.post_id = '{$post_id}'
					    			AND c.category_status = 'Active'";
					    		$category_result = $database->execute_query($category_query);
					    		if ($category_result->num_rows >  0) {
					    			while($categories = mysqli_fetch_assoc($category_result)){
					    	?>
								<span class="badge text-bg-warning">
									<?= $categories['category_title'] ?>
								</span>
					    	<?php			
					    			}
					    		}
					    	?>
					    </p>
					    <h6 class="border-start my-3 border-3 px-2 text-secondary lead" style="font-size:18px">Attachments</h6>
				    	<?php 
				    		$attachments = "SELECT * FROM post_atachment WHERE post_id = '{$post_id}'";
				    		$attachments_result = $database->execute_query($attachments);
				    		if ($attachments_result->num_rows >  0) {
				    			while($attachments = mysqli_fetch_assoc($attachments_result)){
				    				require_once('assets/user/file-types.php');
									$type = $attachments['post_attachment_path'];
									$type = explode(".", $type);
									$type = end($type);
									$type = strtolower($type);
									$icon = null;
									foreach ($file_types as $key => $value) {
										if ($key == $type) {
											$icon = $value;
										}
									}
									$icon = $icon??$file_types['other'];

				    	?>
						    <p class="p-0 m-0 mt-2" style="font-size:15px">
						    	
								<a href="uploads/attachments/<?= $attachments['post_attachment_path'] ?>" class="badge bg-info-subtle text-dark" download="" >
								<img src="assets/images/<?= $icon ?>" style="width:30px;" class="mx-1">	
									<?= $attachments['post_attachment_title'] ?>
								</a>
						    </p>
				    	<?php			
				    			}
				    		}
				    	?>

				 	</div>
				</div>
				<!--/ post details -->
				<!-- show Comments -->
				<div class="m-md-2 mt-3 p-2 message_container shadow rounded" >
					<h6 class="border-start my-3 border-3 px-2 text-secondary lead" style="font-size:18px">Comments</h6>
					<?php 	
						$query = "SELECT pc.*,u.first_name,u.last_name,u.user_image FROM post_comment pc JOIN post p USING(post_id) JOIN USER u USING(user_id)  WHERE p.post_id = {$post_id} AND pc.is_active = 'Active' 
							ORDER BY pc.post_comment_id DESC 
							LIMIT 5";
						$result = $database->execute_query($query);
						if ($result->num_rows > 0) {
							while($comments = mysqli_fetch_assoc($result)){
					?>

					<div class="border p-2 mb-3 rounded message">	
						<div class="d-flex align-items-center" style="">
							<div class="">	
								<img src="uploads/profile-images/<?= $comments['user_image'] ?>" class="rounded-circle" alt="" style="width:45px;height:45px">
							</div>
							<p class="m-0 mx-2 fw-bold"><?= $comments['first_name']." ".$comments['last_name'] ?></p>
						</div>
						<p class="border-start border-3 px-2 my-2" style="font-size: 15px;">	
							<?= $comments['comment'] ?>	
						</p>
						<p>	
							<span class="border-start border-3 px-2 text-secondary lead" style="font-size: 15px;">
					    	<i><?=  date("d M Y  H:i:s A",strtotime($comments['created_at']))  ?></i>
					    </span>
						</p>
					</div>	
					<?php
							}
						}
						else{
							echo "No Comments";
						}
					?>
				</div>
				<!-- /show Comments -->
				<!-- comment  -->
				<?php if ($is_comment_allowed == 1): ?>
					<form id="comment_form" class="rounded shadow p-2 m-md-2 my-3">
						<div id="comment_message">	
						</div>
						<h3 class="mt-3">Leave a Comment</h3>
						
						<input type="hidden" name="post_id"  value="<?= $post_id ?>">
						<input type="hidden" name="user_id"  value="<?= $user_id ?>">
						<div class="form-floating my-3">
						  <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px" name="comment"></textarea>
						  <label for="floatingTextarea2">Comments</label>
						</div>
						<p class="px-1 text-danger mb-3" style="font-size:12px" id="comment_msg">
						</p>
						<div class="text-end">
							<input type="button" class="btn btn-primary" name="comment" value="Comment" onclick="leave_comment()">
						</div>
					</form>
				<?php endif ?>
				
				<!--/ comment  -->
			</div>
			<div class="col-md-4 sidebar">
				<?php 
					include('assets/user/sidebar.php');
				?>	
			</div>
		</div>
		<?php 
		}else{
		} 
		?>
	</div>
	<!-- content -->
<?php 
	include("assets/user/user-footer.php");
?>	