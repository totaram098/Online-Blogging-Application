<?php 
	include("assets/user/user-header.php");
?>
	<!-- content -->
	<div class="container-fluid my-5">
		<div class="row">
			<div class="col-md-8 p-0">
				<!-- post details -->
				<div class="card border border-0 mb-3">

					<!-- <div class="border"></div> -->
				  	<div class="card-body  shadow  m-md-2 p-sm-4">
					    <h1 class="card-title border-start border-5 px-2 mb-4">POSTS</h1>
					    <div class="row mb-4">
					    	<?php 	
					    		$posts_per_page = 9;
					    		$start = $_REQUEST['page']??1;
					    		$current_page = $start;
					    		$start = ($start-1) * $posts_per_page;
					    		$query = "SELECT p.*,u.first_name,u.last_name FROM post p JOIN blog b USING(blog_id) JOIN USER u USING(user_id)
					    			WHERE p.post_status = 'Active' AND b.blog_status = 'Active'
					    			ORDER BY p.post_id DESC
					    			LIMIT $start,$posts_per_page";
					    		$result = $database->execute_query($query);
					    		if ($result->num_rows > 0) {
					    			while ($post_data = mysqli_fetch_assoc($result)) {
					    	?>
					    	<div class="col-md-6 col-lg-4 p-2">
					    		<a href="post-details.php?id=<?= $post_data['post_id']; ?>&post_details" class="text-decoration-none">
						    		<div class="card h-100 shadow border border-0">
									  <img src="uploads/post-images/<?= $post_data['featured_image'] ?>" class="card-img-top" alt="...">
									  <div class="card-body">
									    <h5 class="card-title"><?= $post_data['post_title'] ?></h5>
									    <span class="card-title text-secondary" style="font-size: 15px;"><i><?= $post_data['first_name']." ". $post_data['last_name'] ?></i></span>
									    <p class="card-text mt-2">
									    	<?= substr($post_data['post_summary'],0,100) ?>
									    	<?php $length = strlen($post_data['post_summary']) ?>
										    <?= (($length>100)?"...":"") ?>
								    	</p>
										
									<?php 
							    		$post_id = $post_data['post_id'];
							    		$category_query = "SELECT * FROM category c JOIN post_category pc USING(category_id) WHERE pc.post_id = '{$post_id}'";
							    		$category_result = $database->execute_query($category_query);
							    		if ($category_result->num_rows >  0) {
							    			while($categories = mysqli_fetch_assoc($category_result)){
							    	?>
									<span class="badge text-bg-warning">
										<?= $categories['category_title'] ?>
									</span>
							    	<?php			
							    			}
							    		}
							    	?>
									  </div>
									</div>
					    		</a>
					    	</div>
					    	<?php			
					    			}
					    		}else{
					    			echo "No Post Found.";
					    		}
					    	?>
					    </div>
					    <?php 	
					    		$count_posts = "SELECT COUNT(post_id) total_posts FROM post p JOIN blog b USING(blog_id) WHERE p.post_status = 'Active' AND b.blog_status = 'Active' ";
					    		$count_result = $database->execute_query($count_posts);
					    		if ($count_result->num_rows > 0) {
					    			$total_posts = mysqli_fetch_assoc($count_result);
					    			if ($total_posts['total_posts'] > 0) {
					    				
					    			
					    ?>
					    <nav aria-label="Page navigation example">
							<ul class="pagination justify-content-center">
						
					    <?php			
					    			
					    			$total_posts = $total_posts['total_posts'];
						    		$pages = ceil($total_posts/$posts_per_page);
									$prev = ($current_page==1)?"disabled":"";
									$next = ($current_page==$pages)?"disabled":"";
						?>
								<li class="page-item  <?= $prev ?>">
							      <a class="page-link"  href="posts.php?posts&page=<?= ($current_page-1) ?>">Previous</a>
							    </li>
						<?php    		
						    		for ($i=1; $i <= $pages ; $i++) { 
						?>

							 	<li class="page-item">
							 		<a class="page-link" href="posts.php?posts&page=<?= $i ?>">
							 			<?= $i ?>		
								 	</a>
							 	</li>
						<?php    			
						    		}
						?>
								<li class="page-item <?= $next ?> ">
							      <a class="page-link"  href="posts.php?posts&page=<?= ($current_page+1) ?>">Next</a>
							    </li>
							 </ul>
						</nav>
						<?php    		
					    		
					    		}
					    	}
					    ?>
					    
				 	</div>
				</div>
				<!--/ post details -->
			</div>
			<div class="col-md-4 sidebar">
				<?php 
					include('assets/user/sidebar.php');
				?>	
			</div>
		</div>
	</div>
	<!-- content -->
<?php 
	include("assets/user/user-footer.php");
?>	