<?php 
	include("assets/user/user-header.php");
?>
	<div class="container">
		<?php
			if (!isset($_GET['change_password'])) {
			?>
			<script>
				window.location.href = "index.php";
			</script>
			<?php

			}
			if (isset($_SESSION['message'])) {
				extract($_SESSION['message']);
				if (isset($data) && is_array($data)) {
					extract($data);
				}
			}
		?>
		<div class="row justify-content-center p-0 m-0 align-items-center my-3" style="min-height: 70vh;">
			<div class="col-md-6 col-sm-10">
			<h1 class="border-start border-5 bg-secodary shadow px-3 py-3 rounded mb-3">CHANGE PASSWORD</h1>
			<?= $_SESSION['msg']?? "" ?>
			<form action="database/user/user-process.php" onsubmit="return validate_password();" method="POST" class="shadow p-sm-3 p-2 rounded">
	  				<div class="row justify-content-center">
	  					<div class="col-11">
	  						<div class="form-floating">
							  <input type="password" class="form-control" id="floatingInput" placeholder="Old Password" name="old_password" value="<?= $password??""; ?>">
							  <label for="floatingInput">Old Password</label>
							</div>
							<p class="px-1 text-danger mb-3" style="font-size:12px" id="old_password_msg">
								<?= $old_password_msg ?? "";?>
							</p>
	  					</div>
	  				</div>
	  				<div class="row justify-content-center">
	  					<div class="col-11">
	  						<div class="form-floating">
							  <input type="password" class="form-control" id="floatingInput" placeholder="Password" name="new_password" value="<?= $new_password??""; ?>">
							  <label for="floatingInput">New Password</label>
							</div>
							<p class="px-1 text-danger mb-3" style="font-size:12px" id="new_password_msg">
								<?= $new_password_msg ?? "";?>
							</p>
	  					</div>
	  				</div>
	  				<div class="row justify-content-center">
	  					<div class="col-11">
	  						<div class="form-floating">
							  <input type="password" class="form-control" id="floatingInput" placeholder="Password" name="confirm_password" value="<?= $confirm_password??""; ?>">
							  <label for="floatingInput">Confirm Password</label>
							</div>
							<p class="px-1 text-danger mb-3" style="font-size:12px" id="confirm_password_msg">
								<?= $confirm_password_msg ?? "";?>
							</p>
	  					</div>
	  				</div>
	  				<div class="row justify-content-center">
	  					<div class="col-11">
	  						<div class="row justify-content-end">
			  					<div class="col-md-3 col-sm-6 mb-2 col-12">
			  						<input type="reset" name="reset" value="Clear" class="form-control btn btn-danger">
			  					</div>
			  					<div class="col-md-3 col-sm-6 col-12">
			  						<input type="Submit" name="change_password" value="Submit" class="form-control btn btn-primary">
			  					</div>
							</div>
	  					</div>
	  				</div>
	  			</form>
  			<?php 
				if (isset($_SESSION['message'])) {
					session_destroy();
				}
			?>
			</div>
		</div>
		<script>
			function validate_password(){

				var password_alphabetical_pattern = /[a-z]{1}/;
				var password_capital_pattern = /[A-Z]{1}/;
				var password_numeric_pattern = /[0-9]{1}/;

				is_valid = true;
				$old_password = document.querySelector('input[name=old_password]').value;
				$new_password = document.querySelector('input[name=new_password]').value;
				$confirm_password = document.querySelector('input[name=confirm_password]').value;
				if ($old_password=="" || $old_password==" ") {
					is_valid = false;
					document.querySelector('#old_password_msg').innerHTML = "This Field Is Required..!";
				}else{
					document.querySelector('#old_password_msg').innerHTML = "";
				}

				if ($new_password=="" || $new_password==" ") {
					is_valid = false;
					document.querySelector('#new_password_msg').innerHTML = "This Field Is Required..!";
				}else{
					document.querySelector('#new_password_msg').innerHTML = "";
					is_correct_password = true;
					if(!($new_password.length > 7 )){
						is_correct_password = false;
					}
					else if(!(password_alphabetical_pattern.test($new_password))){
						is_correct_password = false;
					}
					else if(!(password_numeric_pattern.test($new_password))){
						is_correct_password = false;
					}
					else if(!(password_capital_pattern.test($new_password))){
						is_correct_password = false;
					}

					if(!is_correct_password){
						document.querySelector('#new_password_msg').innerHTML = "Password Must Contain at Least 8 Characters, Capital, Small and Numeric Characters.";
					}
				}

				if ($confirm_password=="" || $confirm_password==" ") {
					is_valid = false;
					document.querySelector('#confirm_password_msg').innerHTML = "This Field Is Required..!";
				}else{
					document.querySelector('#confirm_password_msg').innerHTML = "";
				}

				if ($confirm_password != $new_password) {
					is_valid = false;
					document.querySelector('#confirm_password_msg').innerHTML = "Password Does Not Match..!";
				}
				return is_valid;
			}
		</script>
	</div>
<?php 
	include("assets/user/user-footer.php");
?>