<?php 
	include("assets/user/user-header.php");
?>
	<div class="container">
		<?php
			if (!isset($_GET['forget_password'])) {
			?>
			<script>
				window.location.href = "index.php";
			</script>
			<?php

			}
		 
			if (isset($_SESSION['message'])) {
				extract($_SESSION['message']);
				if (isset($data)) {
					extract($data);
				}
			}
		?>
		<div class="row justify-content-center p-0 m-0 align-items-center" style="min-height: 70vh;">
			<div class="col-md-6 col-sm-10">
			<h1 class="border-start border-5 bg-secodary shadow px-3 py-3 rounded mb-3">FORGET PASSWORD</h1>
			<?= $_SESSION['msg']?? "" ?>
			<form action="database/user/user-process.php" onsubmit="return is_email_empty()" method="POST" class="shadow p-sm-3 p-2 rounded">
	  				<div class="row justify-content-center">
	  					<div class="col-11">
							<div class="form-floating ">
							  <input type="text" class="form-control" id="floatingInput" placeholder="example123@gmail.com" name="email" value="<?= $email??""; ?>">
							  <label for="floatingInput">Email</label>
							</div>
							<p class="px-1 text-danger mb-3" style="font-size:12px" id="email_msg">
								<?= $email_msg ?? "";?>
							</p>
	  					</div>
	  				</div>

	  				<div class="row justify-content-center">
	  					<div class="col-11">
	  						<div class="row justify-content-end">
			  					<div class="col-md-3 col-sm-6 mb-2 col-12">
			  						<input type="reset" name="reset" value="Clear" class="form-control btn btn-danger">
			  					</div>
			  					<div class="col-md-3 col-sm-6 col-12">
			  						<input type="Submit" name="forget_password" value="Submit" class="form-control btn btn-primary">
			  					</div>
							</div>
	  					</div>
	  				</div>
	  			</form>
  			<?php 
				if (isset($_SESSION['message'])) {
					session_destroy();
				}
			?>
			</div>
		</div>
		<script>
			function is_email_empty(){
				var email = document.querySelector("input[name=email]").value;
				if (email=="" || email==" ") {
					document.querySelector("#email_msg").innerHTML = "Email Is Required..!";
					return false;
				}else{
					document.querySelector("#email_msg").innerHTML = "";
					return true;
				}
			}
		</script>
	</div>
<?php 
	include("assets/user/user-footer.php");
?>