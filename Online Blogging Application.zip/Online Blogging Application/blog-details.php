<?php 
	include("assets/user/user-header.php");
?>
	<!-- content -->
	<div class="container-fluid my-5">
			<?php
			if (!(isset($_GET['id']) && $_GET['id'])) {
			?>
			<script>
				window.location.href = "index.php";
			</script>
			<?php

			} 
			if (!isset($_GET['blog_details'])) {
			?>
			<script>
				window.location.href = "index.php";
			</script>
			<?php

			}
			?>
		<div class="row">
			<div class="col-md-8">
				<!-- post details -->
				<div class="card mb-3">
					<?php 
						$blog_id = $_REQUEST['id']??0;
						$query = "SELECT b.*,u.first_name,u.last_name,u.user_image,COUNT(fb.follow_id) follower FROM blog b 
							LEFT JOIN following_blog fb ON fb.blog_following_id = b.blog_id  
							JOIN USER u USING(user_id)
							WHERE b.blog_id = {$blog_id}
							GROUP BY b.blog_id";
						$result = $database->execute_query($query);
						if ($result->num_rows > 0) {
							$blog_data = mysqli_fetch_assoc($result);
					?>

				  	<img src="uploads/blog-images/<?= $blog_data['blog_background_image'] ?>"  style="max-height: 50vh; object-fit: cover;" class="card-img-top" alt="...">
				  	<div class="mx-2 border-start border-3 d-flex align-items-center my-2">
				  		<img src="uploads/profile-images/<?= $blog_data['user_image'] ?>" alt=""  style="width:50px;height: 50px; border-radius: 50px;" class="mx-2">
				  		<h5 class="m-0">
				  			<?= $blog_data['first_name']." ". $blog_data['last_name'] ?>
				  			<br>
				  			<span class=" text-secondary lead" style="font-size: 15px;">
					    	<i>Since <?=  date("d M Y",strtotime($blog_data['created_at']))  ?></i>
					    </span>
				  		</h5>
				  	</div>
				  	<h2 class="shadow rounded row justify-content-between p-2 m-2 py-3">
				  		<span class="text-secondary " style="font-size:10px">Blog Title</span>
						<span class="col-sm-9"><?= $blog_data['blog_title'] ?></span>

				  		<?php 
				  			$follower_id = $user_data["user_id"];
				  			$blog_id = $blog_data['blog_id'];
				  			$follow_query = "SELECT * FROM following_blog WHERE 
				  			follower_id = {$follower_id} AND blog_following_id = {$blog_id}";
				  			$follow_result = $database->execute_query($follow_query);
				  			$follow = "Follow";
				  			if ($follow_result->num_rows > 0) {
					  			$follow = "Unfollow";
				  			}
				  		?>
				  		<?php if ($blog_data['user_id'] != $user_data['user_id']): ?>
							<a style="cursor:pointer;" onclick="follow_blog(<?= $blog_id ?>,<?= $follower_id ?>,'<?= $follow ?>')" class="btn border btn-primary col-sm-2 m-sm-0 mt-3">
								<span id="is_follow"><?= $follow; ?></span> 
								<span class="badge text-bg-warning" id="followers"><?= $blog_data['follower']; ?></span>
							</a>
				  		<?php endif ?>
						
					</h2>
				  	<div class="card-body m-2">
					    <h2 class="card-title border-start border-3 px-2">POSTS</h2>
					    <div class="row mb-4">
					    	<?php 	
					    		$posts_per_page = $blog_data['post_per_page'];
					    		$start = $_REQUEST['page']??1;
					    		$current_page = $start;
					    		$start = ($start-1) * $posts_per_page;
					    		$query = "SELECT p.*,u.first_name,u.last_name FROM post p JOIN blog b USING(blog_id) JOIN USER u USING(user_id)
									WHERE p.blog_id = {$blog_id} AND p.post_status = 'Active'
									ORDER BY p.post_id DESC
									LIMIT $start,$posts_per_page";
					    		$result = $database->execute_query($query);
					    		if ($result->num_rows > 0) {
					    			while ($post_data = mysqli_fetch_assoc($result)) {
					    	?>
					    	<div class="col-md-6 col-lg-4 p-2">
					    		<a href="post-details.php?id=<?= $post_data['post_id']; ?>&post_details" class="text-decoration-none">
						    		<div class="card h-100 shadow border border-0">
									  <img src="uploads/post-images/<?= $post_data['featured_image'] ?>" class="card-img-top" alt="...">
									  <div class="card-body">
									    <h5 class="card-title"><?= $post_data['post_title'] ?></h5>
									    <span class="card-title text-secondary" style="font-size: 15px;"><i><?= $post_data['first_name']." ". $post_data['last_name'] ?></i></span>
									    <p class="card-text mt-2">
									    	<?= substr($post_data['post_summary'],0,100) ?>
									    	<?php $length = strlen($post_data['post_summary']) ?>
										    <?= (($length>100)?"...":"") ?>
								    	</p>
										
									<?php 
							    		$post_id = $post_data['post_id'];
							    		$category_query = "SELECT * FROM category c JOIN post_category pc USING(category_id) WHERE pc.post_id = '{$post_id}' AND c.category_status = 'Active' ";
							    		$category_result = $database->execute_query($category_query);
							    		if ($category_result->num_rows >  0) {
							    			while($categories = mysqli_fetch_assoc($category_result)){
							    	?>
									<span class="badge text-bg-warning">
										<?= $categories['category_title'] ?>
									</span>
							    	<?php			
							    			}
							    		}
							    	?>
									  </div>
									</div>
					    		</a>
					    	</div>
					    	<?php			
					    			}
					    		}else{
					    			echo "No Post Found..!";
					    		}
					    	?>
					    </div>
					    <?php 	
					    		$count_posts = "SELECT COUNT(post_id) total_posts FROM post 
					    		WHERE blog_id = {$blog_id}";
					    		$count_result = $database->execute_query($count_posts);
					    		if ($count_result->num_rows > 0) {
					    			$total_posts = mysqli_fetch_assoc($count_result);
					    			if ($total_posts['total_posts'] > 0) {
					    ?>
					    <nav aria-label="Page navigation example">
							<ul class="pagination justify-content-center">
						
					    <?php			
					    			$total_posts = $total_posts['total_posts'];
						    		$pages = ceil($total_posts/$posts_per_page);
									$prev = ($current_page==1)?"disabled":"";
									$next = ($current_page==($pages))?"disabled":"";
						?>
								<li class="page-item  <?= $prev ?>">
							      <a class="page-link"  href="blog-details.php?id=<?= $blog_id ?>&blog_details&page=<?= ($current_page-1) ?>">Previous</a>
							    </li>
						<?php    		
						    		for ($i=1; $i <= $pages ; $i++) { 
						?>

							 	<li class="page-item">
							 		<a class="page-link" href="blog-details.php?id=<?= $blog_id ?>&blog_details&page=<?= $i ?>">
							 			<?= $i ?>		
								 	</a>
							 	</li>
						<?php    			
						    		}
						?>
								<li class="page-item <?= $next ?> ">
							      <a class="page-link"  href="blog-details.php?id=<?= $blog_id ?>&blog_details&page=<?= ($current_page+1) ?>">Next</a>
							    </li>
							 </ul>
						</nav>
						<?php    		
					    		}
					    	}
					    ?>
				 	</div>

					<?php		
						}	
					?>
				</div>
				<!--/ post details -->
			</div>
			<div class="col-md-4 sidebar">
				<?php 
					include('assets/user/sidebar.php');
				?>	
			</div>
		</div>
	</div>
	<!-- content -->
<?php 
	include("assets/user/user-footer.php");
?>	