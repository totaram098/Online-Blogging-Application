<?php 
	session_start();
	require("../../config/database.php");
	require('../../Mailing and PDF/PHPMailer.php');
	require("../../Mailing and PDF/mailing/manage-emails.php");
	require("../../admin/validation/registration.php");
	require("../../admin/validation/blog.php");
	require("../../admin/validation/post.php");
	require("../../admin/validation/category.php");
	$user_data = unserialize($_COOKIE['user_data']);
	$user_id = $user_data['user_id'];
	if(isset($_POST['adduser'])){
		$validate = validate_registration();
		extract($_POST);
		$filename = "../../uploads/profile-images";
		$temp_name = $_FILES['user_image']['tmp_name'];
		if (!is_dir($filename)) {
			mkdir($filename);
		}

		$type = $_FILES['user_image']['name'];
		$type = explode(".", $type);
		$type = end($type);
		$user_image = time()."_profile.".$type;
		$filename.= "/".$user_image;
		if ($validate) {
			if (move_uploaded_file($temp_name, $filename)) {
				$role = ($role_id)?$role_id:2;
				$address = htmlspecialchars($address);
				$query = "INSERT INTO user VALUES(null,'{$role}','{$first_name}','{$last_name}','{$email}','{$password}','{$gender}','{$date_of_birth}','{$user_image}','{$address}','Approved','Active',NOW(),null)";
				$result = $database->execute_query($query);
				if ($result) {
					$user_id = mysqli_insert_id($database->connection);
					$send_email->registration($user_id,"register");
					$_SESSION['msg'] = '<p class="alert alert-success shadow my-3" role="alert"> User Added Successfully..!</p>';
					header("location:../../admin/index.php?adduser");
					exit();
				}else{
					$_SESSION['msg'] = '<p class="alert alert-danger shadow my-3" role="alert"> Could Not Add User..!</p>';
					header("location:../../admin/index.php?adduser");
					exit();
				}
			}else{
				$_SESSION['msg'] = '<p class="alert alert-danger shadow my-3" role="alert"> Could Not Add User..!</p>';
					header("location:../../admin/index.php?adduser");
					exit();
			}
		}else{
			$_SESSION['message']['data'] = $_POST;
			header("location:../../admin/index.php?adduser");
			exit();
		}
	}
	elseif(isset($_POST['edituser'])){
		$validate = validate_registration('edituser');
		extract($_POST);
		if ($validate) {

			$filename = "../../uploads/profile-images";
			if ($_FILES['user_image']['tmp_name']) {
				if (!is_dir($filename)) {
					mkdir($filename);
				}
				unlink("../../uploads/profile-images/".$profile_image);
				$type = $_FILES['user_image']['name'];
				$type = explode(".", $type);
				$type = end($type);
				$user_image = time()."_profile.".$type;
				$temp_name = $_FILES['user_image']['tmp_name'];
				$filename.= "/".$user_image;
				if (!move_uploaded_file($temp_name, $filename)) {
					$_SESSION['msg'] = '<p class="alert alert-danger shadow my-3" role="alert"> Could Not Update User..!</p>';
					header("location:../../admin/index.php?getusers");
					exit();

				}
			}else{
				$user_image = $profile_image;
			}
			$address = htmlspecialchars($address);
			$query = "UPDATE user SET first_name = '{$first_name}', last_name = '{$last_name}', gender = '{$gender}',  date_of_birth = '{$date_of_birth}', user_image = '{$user_image}', address = '{$address}', role_id = '{$role_id}', updated_at = NOW() WHERE user_id = '{$user_id}'";
			$result = $database->execute_query($query);
			if ($result) {
				$send_email->registration($user_id,"update");
				$_SESSION['msg'] = '<p class="alert alert-success shadow my-3" role="alert"> User Updated Successfully..!</p>';
					header("location:../../admin/index.php?getusers");
					exit();
			}else{
				$_SESSION['msg'] = '<p class="alert alert-danger shadow my-3" role="alert"> Could Not Update User..!</p>';
				header("location:../../admin/index.php?getusers");
				exit();
			}

		}else{
			$_SESSION['message']['data'] = $_POST;
			header("location:../../admin/index.php?edituser");
		}
	}

	elseif(isset($_POST['addblog'])){
		$validate = validate_blog();
		extract($_POST);
		$filename = "../../uploads/blog-images";
		$temp_name = $_FILES['blog_background_image']['tmp_name'];
		if (!is_dir($filename)) {
			mkdir($filename);
		}

		$type = $_FILES['blog_background_image']['name'];
		$type = explode(".", $type);
		$type = end($type);
		$blog_background_image = time()."_blog.".$type;
		$filename.= "/".$blog_background_image;
		if ($validate) {
			if (move_uploaded_file($temp_name, $filename)) {
				$blog_title = htmlspecialchars($blog_title);
				$query = "INSERT INTO blog VALUES(null,{$user_id},'{$blog_title}','{$post_per_page}','{$blog_background_image}','{$blog_status}',NOW(),null)";
				$result = $database->execute_query($query);
				if ($result) {
					$_SESSION['msg'] = '<p class="alert alert-success shadow my-3" role="alert"> Blog Has Been Added Successfully..!</p>';
					header("location:../../admin/index.php?addblog");
					exit();
				}else{
					$_SESSION['msg'] = '<p class="alert alert-danger shadow my-3" role="alert"> Could Not Add Blog..!</p>';
					header("location:../../admin/index.php?addblog");
					exit();
				}
			}
		}else{
			$_SESSION['message']['data'] = $_POST;
			header("location:../../admin/index.php?addblog");
			exit();
		}
	}
	elseif(isset($_POST['editblog'])){
		$validate = validate_blog('editblog');
		extract($_POST);

		if ($validate) {

			$filename = "../../uploads/blog-images";
			if ($_FILES['blog_background_image']['tmp_name']) {
				if (!is_dir($filename)) {
					mkdir($filename);
				}
				unlink("../../uploads/blog-images/".$blog_image);
				$type = $_FILES['blog_background_image']['name'];
				$type = explode(".", $type);
				$type = end($type);
				$blog_background_image = time()."_blog.".$type;
				$temp_name = $_FILES['blog_background_image']['tmp_name'];
				$filename.= "/".$blog_background_image;
				if (!move_uploaded_file($temp_name, $filename)) {
					$_SESSION['msg'] = '<p class="alert alert-danger shadow my-3" role="alert"> Could Not Update Blog..!</p>';
					header("location:../../admin/index.php?getblogs");
					exit();

				}
			}else{
				$blog_background_image = $blog_image;
			}
			$blog_title = htmlspecialchars($blog_title);
			$query = "UPDATE blog SET blog_title='{$blog_title}', post_per_page='{$post_per_page}', blog_background_image='{$blog_background_image}', blog_status='{$blog_status}',updated_at = NOW() WHERE blog_id = '{$blog_id}' ";
			$result = $database->execute_query($query);
			if ($result) {
				$_SESSION['msg'] = '<p class="alert alert-success shadow my-3" role="alert"> Blog Updated Successfully..!</p>';
					header("location:../../admin/index.php?getblogs");
					exit();
			}else{
				$_SESSION['msg'] = '<p class="alert alert-danger shadow my-3" role="alert"> Could Not Update Blog..!</p>';
				header("location:../../admin/index.php?getblogs");
				exit();
			}

		}else{
			$_SESSION['message']['data'] = $_POST;
			header("location:../../admin/index.php?editblog");
			exit();
		}
	}
	elseif(isset($_POST['addpost'])){
		$validate = validate_post();
		extract($_POST);
		$filename = "../../uploads/post-images";
		$temp_name = $_FILES['featured_image']['tmp_name'];
		if (!is_dir($filename)) {
			mkdir($filename);
		}

		$type = $_FILES['featured_image']['name'];
		$type = explode(".", $type);
		$type = end($type);
		$featured_image = time()."_post.".$type;
		$filename.= "/".$featured_image;
		if ($validate) {

			if (move_uploaded_file($temp_name, $filename)) {
				$post_title = htmlspecialchars($post_title);
				$is_comment_allowed = $is_comment_allowed ?? 0;
				$post_summary = htmlspecialchars($post_summary);
				$post_description = htmlspecialchars($post_description);
				$query = "INSERT INTO post VALUES(null,'{$blog_id}','{$post_title}','{$post_summary}','{$post_description}','{$featured_image}','{$post_status}','{$is_comment_allowed}',NOW(),null)";
				$result = $database->execute_query($query);
				if ($result) {
					$post_id = mysqli_insert_id($database->connection);
					foreach ($categories as  $category_id) {
						$query = "INSERT INTO post_category VALUES(null,'{$post_id}','{$category_id}',NOW(),null)";
						$result = $database->execute_query($query);
					}
					$counter = 0;
					if (isset($attachment_title)) {
						foreach ($attachment_title as  $title) {
							$filename = "../../uploads/attachments";
							if ($_FILES['attachment']['tmp_name'][$counter]) {
								$temp_name = $_FILES['attachment']['tmp_name'][$counter];
								if (!is_dir($filename)) {
									mkdir($filename);
								}

								$type = $_FILES['attachment']['name'][$counter];
								$type = explode(".", $type);
								$type = end($type);
								$post_attachment_path = time()."_attachment.".$type;
								$filename.= "/".$post_attachment_path;
								move_uploaded_file($temp_name, $filename);
								$title =  htmlspecialchars($title);
								$query = "INSERT INTO post_atachment VALUES(null,'{$post_id}','{$title}','{$post_attachment_path}','Active',NOW(),null)";
								$result = $database->execute_query($query);
								$counter++;
							}
						}
					}
					$send_email->post_update($post_id,$blog_id);
					$_SESSION['msg'] = '<p class="alert alert-success shadow my-3" role="alert">Post Added Successfully..!</p>';
					header("location:../../admin/index.php?addpost");
					exit();

				}else{
					$_SESSION['msg'] = '<p class="alert alert-danger shadow my-3" role="alert"> Could Not Add Post..!</p>';
					header("location:../../admin/index.php?addpost");
					exit();
				}
			}else{
				$_SESSION['msg'] = '<p class="alert alert-danger shadow my-3" role="alert"> Could Not Add Post..!</p>';
				header("location:../../admin/index.php?addpost");
				exit();
			}
		}else{
			$_SESSION['message']['data'] = $_POST;
			header("location:../../admin/index.php?addpost");
		}
	}
	elseif(isset($_POST['editpost'])){
		$validate = validate_post("editpost");
		extract($_POST);
		if ($validate) {
			$category_ids = implode(",", $categories);
			$update_category = "DELETE FROM post_category WHERE post_id = '{$post_id}'";
			$result = $database->execute_query($update_category);
			$update_attachment = "DELETE FROM post_atachment WHERE post_id = '{$post_id}'";
			$result = $database->execute_query($update_attachment);
			
			$filename = "../../uploads/post-images";
			if ($_FILES['featured_image']['tmp_name']) {
				if (!is_dir($filename)) {
					mkdir($filename);
				}
				unlink("../../uploads/post-images/".$post_image);
				$type = $_FILES['featured_image']['name'];
				$type = explode(".", $type);
				$type = end($type);
				$featured_image = time()."_post.".$type;
				$temp_name = $_FILES['featured_image']['tmp_name'];
				$filename.= "/".$featured_image;
				if (!move_uploaded_file($temp_name, $filename)) {
					$_SESSION['msg'] = '<p class="alert alert-danger shadow my-3" role="alert"> Could Not Add Post..!</p>';
					header("location:../../admin/index.php?getposts");
					exit();

				}
			}else{
				$featured_image = $post_image;
			}
			$is_comment_allowed = $is_comment_allowed ?? 0;
			$post_title = htmlspecialchars($post_title);
			$post_summary = htmlspecialchars($post_summary);
			$post_description = htmlspecialchars($post_description);
			$query = "UPDATE post SET blog_id ='{$blog_id}',  post_title = '{$post_title}',  post_summary = '{$post_summary}',  post_description ='{$post_description}', featured_image = '{$featured_image}', post_status = '{$post_status}',is_comment_allowed = '{$is_comment_allowed}',updated_at = NOW() WHERE post_id = '{$post_id}'";
			$result = $database->execute_query($query);
			if ($result) {
				foreach ($categories as  $category_id) {
					$query = "INSERT INTO post_category VALUES(null,'{$post_id}','{$category_id}',null,NOW())";
					$result = $database->execute_query($query);
				}
				$counter = 0;
				if (isset($attachment_title)) {
					foreach ($attachment_title as  $title) {
						$filename = "../../uploads/attachments";
						if ($_FILES['attachment']['tmp_name'][$counter]) {
							$temp_name = $_FILES['attachment']['tmp_name'][$counter];
							if (!is_dir($filename)) {
								mkdir($filename);
							}
							unlink( "../../uploads/attachments/".$post_attachments[$counter]);
							$type = $_FILES['attachment']['name'][$counter];
							$type = explode(".", $type);
							$type = end($type);
							$post_attachment_path = time()."_attachment.".$type;
							$filename.= "/".$post_attachment_path;
							move_uploaded_file($temp_name, $filename);
							$title =  htmlspecialchars($title);
							$query = "INSERT INTO post_atachment VALUES(null,'{$post_id}','{$title}','{$post_attachment_path}','Active',null,NOW())";
							$result = $database->execute_query($query);
							$counter++;
						}else{
							$post_attachment_path = $post_attachments[$counter];
							$query = "INSERT INTO post_atachment VALUES(null,'{$post_id}','{$title}','{$post_attachment_path}','Active',null,NOW())";
							$result = $database->execute_query($query);
							$counter++;
						}
					}
				}
				$_SESSION['msg'] = '<p class="alert alert-success shadow my-3" role="alert">Post Updated Successfully..!</p>';
				header("location:../../admin/index.php?getposts");
				exit();
			}else{
				$_SESSION['msg'] = '<p class="alert alert-danger shadow my-3" role="alert"> Could Not Update Post..!</p>';
				header("location:../../admin/index.php?getposts");
				exit();
			}
		}else{
			$_SESSION['message']['data'] = $_POST;
			header("location:../../admin/index.php?editpost");
				exit();
		}
	}
	elseif(isset($_POST['addcategory'])){
		$validate = validate_category();
		extract($_POST);
		if ($validate) {
			$category_title = htmlspecialchars($category_title);
			$category_description = htmlspecialchars($category_description);
			$query = "INSERT INTO category VALUES(null,'{$category_title}','{$category_description}','{$category_status}',NOW(),null)";
			$result = $database->execute_query($query);
			if ($result) {
				$_SESSION['msg'] = '<p class="alert alert-success shadow my-3" role="alert"> Category Has Been Added Successfully..!</p>';
				header("location:../../admin/index.php?addcategory");
				exit();
			}else{
				$_SESSION['msg'] = '<p class="alert alert-danger shadow my-3" role="alert"> Could Not Add Category..!</p>';
				header("location:../../admin/index.php?addcategory");
				exit();
			}
		}else{
			$_SESSION['message']['data'] = $_POST;
			header("location:../../admin/index.php?addcategory");
		}
	}
	elseif(isset($_POST['editcategory'])){
		$validate = validate_category();
		extract($_POST);

		if ($validate) {

			$category_title = htmlspecialchars($category_title);
			$category_description = htmlspecialchars($category_description);
			$query = "UPDATE category SET category_title = '{$category_title}', category_description = '{$category_description}', category_status = '{$category_status}', updated_at = NOW() WHERE category_id = '{$category_id}'";
			$result = $database->execute_query($query);
			if ($result) {
				$_SESSION['msg'] = '<p class="alert alert-success shadow my-3" role="alert"> Category Updated Successfully..!</p>';
					header("location:../../admin/index.php?getcategories");
					exit();
			}else{
				$_SESSION['msg'] = '<p class="alert alert-danger shadow my-3" role="alert"> Could Not Update Category..!</p>';
				header("location:../../admin/index.php?getcategories");
				exit();
			}

		}else{
			$_SESSION['message']['data'] = $_POST;
			header("location:../../admin/index.php?editcategory");
			exit();
		}
	}
?>