<?php 
	session_start();

	require("../../validation/registration.php");
	require("../../config/database.php");
	require('../../Mailing and PDF/PHPMailer.php');
	require("../../Mailing and PDF/mailing/manage-emails.php");
	require("../../validation/validate_login.php");
	require("../../validation/feedback.php");
	require("../../validation/validate_password.php");
	if(isset($_POST['register'])){
		$validate = validate_registration();
		extract($_POST);

		$filename = "../../uploads/profile-images";
		$temp_name = $_FILES['user_image']['tmp_name'];
		if (!is_dir($filename)) {
			mkdir($filename);
		}

		$type = $_FILES['user_image']['name'];
		$type = explode(".", $type);
		$type = end($type);
		$user_image = time()."_profile.".$type;
		$filename.= "/".$user_image;
		if ($validate) {
			if (move_uploaded_file($temp_name, $filename)) {
				$address = htmlspecialchars($address);
				$query = "INSERT INTO user VALUES(null,'2','{$first_name}','{$last_name}','{$email}','{$password}','{$gender}','{$date_of_birth}','{$user_image}','{$address}','Pending','InActive',NOW(),null)";
				$result = $database->execute_query($query);
				if ($result) {
					$user_id = mysqli_insert_id($database->connection);
					$send_email->registration($user_id,"register");
					$_SESSION['msg'] = '<p class="alert alert-success shadow my-3" role="alert"> You Have Been Regsitered Successfully..!</p>';
					header("location:../../registration.php");
					exit();
				}else{
					$_SESSION['msg'] = '<p class="alert alert-danger shadow my-3" role="alert"> Could Not Regsiter You..!<br>Please Try Again..!</p>';
					header("location:../../registration.php");
					exit();
				}
			}
		}else{
			$_SESSION['message']['data'] = $_POST;
			header("location:../../registration.php");
			exit();
		}
	}
	elseif(isset($_POST['login'])){
		$validate = validate_login();
		extract($_POST);

		if ($validate) {
			$query = "SELECT u.*,r.role_type FROM user u JOIN role r USING(role_id) WHERE email = '{$email}' AND password='{$password}'";
			$result = $database->execute_query($query);
			if ($result->num_rows > 0) {
				$user_data = mysqli_fetch_assoc($result);
				if ($user_data['is_approved'] == "Pending") {
					$_SESSION['msg'] = '<p class="alert alert-danger shadow my-3" role="alert"> Your Account Is Not Approved Yet..!</p>';
					header("location:../../login.php");
					exit();
				}
				elseif ($user_data['is_approved'] == "Rejected") {
					$_SESSION['msg'] = '<p class="alert alert-danger shadow my-3" role="alert"> Your Account Has Been Rejected..!</p>';
					header("location:../../login.php");
					exit();
				}elseif($user_data['is_approved'] == "Approved" && $user_data['is_active'] == "InActive"){
					$_SESSION['msg'] = '<p class="alert alert-danger shadow my-3" role="alert"> Your Account Is Currently InActive..!</p>';
					header("location:../../login.php");
					exit();

				}elseif($user_data['is_approved'] == "Approved" && $user_data['is_active'] == "Active"){
					setcookie("user_data",serialize($user_data),(time()+(3600*24)),"/");
					header("location:../../index.php");
					exit();

				}
			}else{
				$_SESSION['msg'] = '<p class="alert alert-danger shadow my-3" role="alert">Invalid Password Or Email..!</p>';
				header("location:../../login.php");
				exit();
			}
		}else{
			$_SESSION['message']['data'] = $_POST;
			header("location:../../login.php");
			exit();
		}
	}
	elseif(isset($_REQUEST['feedback_form'])){
		extract($_REQUEST);
		$messages = array();

		if (!(validate_feedback($messages))) {
			$msg = '<div class="alert alert-danger py-2" role="alert">
						<ul class="m-0">';
			foreach ($messages as $key => $value) {
				$msg .= "<li>$key : $value</li>";
			}
			$msg .= "</ul>
					</div>";
			echo $msg;	
		}else{
			$feedback = htmlspecialchars($feedback);
			if (isset($user_id)) {
				$query = "INSERT INTO user_feedback VALUES(null,'{$user_id}','{$user_name}','{$user_email}','{$feedback}',NOW())";
				
			}else{
				$query = "INSERT INTO user_feedback VALUES(null,null,'{$user_name}','{$user_email}','{$feedback}',NOW())";
			}
			$result = $database->execute_query($query);
			if ($result) {
				$feedback_id = mysqli_insert_id($database->connection);
				$send_email->feedback($feedback_id);
				echo '<p class="alert alert-success py-2" role="alert">
						Your Feedback Has been Submitted Successfully..!
					</p>';
			}else{
				echo '<p class="alert alert-danger py-2" role="alert">
						Something Went Wrong..! Please Try Again..!
					</p>';
			}
		}
	}
	elseif(isset($_REQUEST['comment_form'])){
		extract($_REQUEST);
		if ($comment =="" || $comment==" ") {
			echo '<p class="alert alert-danger py-2" role="alert">
						Field Is Required..!
					</p>';
		}else{
			$comment = htmlspecialchars($comment);
			$query = "INSERT INTO post_comment VALUES(null,'{$post_id}','{$user_id}','{$comment}','Active',NOW())";
			$result = $database->execute_query($query);
			if ($result) {
				echo '<p class="alert alert-success py-2" role="alert">
						Your Comment Has been Sent Successfully..!
					</p>';
			}else{
				echo '<p class="alert alert-danger py-2" role="alert">
						Something Went Wrong..! Please Try Again..!
					</p>';
			}
		}
	}
	elseif(isset($_REQUEST['edit_profile'])){
		$validate = validate_registration("edit_profile");
		extract($_REQUEST);
		if ($validate) {
			$filename = "../../uploads/profile-images";
			if ($_FILES['user_image']['tmp_name']) {
				if (!is_dir($filename)) {
					mkdir($filename);
				}
				unlink("../../uploads/profile-images/".$profile_image);
				$type = $_FILES['user_image']['name'];
				$type = explode(".", $type);
				$type = end($type);
				$user_image = time()."_profile.".$type;
				$temp_name = $_FILES['user_image']['tmp_name'];
				$filename.= "/".$user_image;
				if (!move_uploaded_file($temp_name, $filename)) {
					$_SESSION['message']['data'] = $_POST;
					$_SESSION['msg'] = '<p class="alert alert-danger shadow my-3" role="alert"> Could Not Edit Your Profile.!<br> Please Try Again..!</p>';
					header("location:../../edit-profile.php?profile");
					exit();

				}
			}else{
				$user_image = $profile_image;
			}
			$address = htmlspecialchars($address);
			$query = "UPDATE user SET first_name = '{$first_name}', last_name = '{$last_name}', gender = '{$gender}',  date_of_birth = '{$date_of_birth}', user_image = '{$user_image}', address = '{$address}', updated_at = NOW() WHERE user_id = '{$user_id}'";
			$result = $database->execute_query($query);
			if ($result) {
				$send_email->registration($user_id,"update");
				$_REQUEST['user_image'] = $user_image;
				$query = "SELECT u.*,r.role_type FROM user u JOIN role r USING(role_id) WHERE user_id = '{$user_id}'";
				$result = $database->execute_query($query);
				$user_data = mysqli_fetch_assoc($result);
				setcookie("user_data",serialize($user_data),(time()+(3600*24)),"/");
				$_SESSION['msg'] = '<p class="alert alert-success shadow my-3" role="alert"> Changes Have Been Saved Successfully..!</p>';
					header("location:../../edit-profile.php?profile");
					exit();
			}else{
				$_SESSION['msg'] = '<p class="alert alert-danger shadow my-3" role="alert"> Could Not Save Changes..!</p>';
				header("location:../../edit-profile.php?profile");
				exit();
			}
		}
		else{
			$_SESSION['message']['data'] = $_POST;
			header("location:../../edit-profile.php?profile");
			exit();
		}
	}
	elseif(isset($_REQUEST['follow_blog'])){
		extract($_REQUEST);
		if ($follow == "Follow") {
			$query = "INSERT INTO following_blog VALUES(null,{$user_id},{$id},'Active',NOW(),null)";
		}else{
			$query = "DELETE FROM following_blog WHERE follower_id = {$user_id} AND blog_following_id = {$id}";
		}
		$result = $database->execute_query($query);
		if ($result) {
			$query = "SELECT COUNT(*) follower FROM following_blog WHERE  blog_following_id = {$id}";
			$result = $database->execute_query($query);
			if ($result->num_rows > 0) {
				$follower = mysqli_fetch_assoc($result);
				echo $follower['follower'];
			}else{
				echo 0;
			}
		}
	}
	elseif(isset($_REQUEST['search_post'])){
		$search = $_REQUEST['search'];
		$search_by = $_REQUEST['search_by']??"";
		if ($search_by == "posts") {
			$query = "SELECT p.*,CONCAT(u.first_name,' ',u.last_name) full_name FROM post p JOIN blog b USING(blog_id) JOIN USER u USING(user_id)
				WHERE p.post_status = 'Active' AND b.blog_status = 'Active' AND (CONCAT(u.first_name,' ',u.last_name) LIKE '%{$search}%' OR p.created_at LIKE '%{$search}%')
				ORDER BY p.post_id DESC";
			$result = $database->execute_query($query);
			if ($result->num_rows > 0) {
				while ($posts = mysqli_fetch_assoc($result)) {
					extract($posts);
			?>
				<a href="post-details.php?id=<?= $post_id; ?>&post_details" class="text-decoration-none text-dark">
					<div class="row my-3 w-100">
						<div class="col-5">
							<img src="uploads/post-images/<?= $featured_image; ?>" class="img-fluid">
						</div>

						<div class="col-7 p-0">
							<h5>
								<?= $post_title; ?>
							</h5>
							<p class="m-0">
								<?= substr($post_summary,0,60) ?>
							</p>
							<p class="m-0 text-secondary">
								Posted By : <?= $full_name; ?>
								
							</p>
							<p class="m-0 text-secondary">
								Posted On : <?= date("d M Y H:i:s A",strtotime($created_at))?>
								
							</p>
						</div>
						<div class="col-12  mt-1">
							<div class=" border-bottom border-2"></div>
						</div>
					</div>
				</a>
			<?php			
				}
			}else{
				echo '<div class="">No Post Found..!</div>';
			}
		}
		elseif($search_by == "blogs"){
			$query = "SELECT b.*,CONCAT(u.first_name,' ',u.last_name) full_name FROM blog b JOIN USER u USING(user_id)
				WHERE  b.blog_status = 'Active' AND (CONCAT(u.first_name,' ',u.last_name) LIKE '%{$search}%' OR b.created_at LIKE '%{$search}%' OR b.blog_title LIKE '%{$search}%')
				ORDER BY blog_id DESC";
			$result = $database->execute_query($query);
			if ($result->num_rows > 0) {
				while ($blogs = mysqli_fetch_assoc($result)) {
					extract($blogs);
			?>
				<a href="blog-details.php?id=<?= $blog_id; ?>&blog_details" class="text-decoration-none text-dark">
					<div class="row my-3 w-100">
						<div class="col-5">
							<img src="uploads/blog-images/<?= $blog_background_image; ?>" class="img-fluid">
						</div>

						<div class="col-7 p-0">
							<h5>
								<?= $blog_title?>
							</h5>
							
							<span style="font-size: 13px;">
								By : 
								<i>
									<?= $full_name ?>
								</i>
							</span>
							<br>
							<span style="font-size: 13px;">
								Created At : 
								<i>
									<?= date("d M Y H:i:s A",strtotime($created_at))?>
								</i>
							</span>
						</div>
						<div class="col-12  mt-1">
							<div class=" border-bottom border-2"></div>
						</div>
					</div>
				</a>
			<?php			
				}
			}else{
				echo '<div class="">No Blog Found..!</div>';
			}
				
		}	
	}
	elseif(isset($_REQUEST['theme_setting'])){
		extract($_REQUEST);
		$setting_status = $theme_active ? "Active" :"InActive";
		if ($is_theme_set == "yes") {
			foreach ($_REQUEST as $key => $value) {
				if ($key == "is_theme_set" || $key == "user_id" || $key == "theme_active" || $key == "theme_setting" ) {
					continue;
				}
				$value = htmlspecialchars($value);
				$query = "UPDATE setting SET setting_value = '{$value}', setting_status = '{$setting_status}', updated_at = NOW()
					WHERE setting_key = '{$key}' AND user_id = {$user_id}";
				$result = $database->execute_query($query);

				if (mysqli_error($database->connection)) {
					echo mysqli_error($database->connection);
					die();
					$_SESSION['msg'] = '<p class="alert alert-danger shadow my-3" role="alert"> Could Not Save Theme Setting..!</p>';
					header("location:../../theme-setting.php?setting");
					exit();
				}	
			}
			$_SESSION['msg'] = '<p class="alert alert-success shadow my-3" role="alert"> Theme Settings Has Been Saved..!</p>';
			header("location:../../theme-setting.php?setting");
			exit();
		}else{
			foreach ($_REQUEST as $key => $value) {
				if ($key == "is_theme_set" || $key == "user_id" || $key == "theme_active" || $key == "theme_setting" ) {
					continue;
				}
				$value = htmlspecialchars($value);
				$query = "INSERT INTO setting VALUES(null,{$user_id},'{$key}','{$value}','{$setting_status}',NOW(),null)";
				$result = $database->execute_query($query);
				if (mysqli_error($database->connection)) {
					$_SESSION['msg'] = '<p class="alert alert-danger shadow my-3" role="alert"> Could Not Save Theme Setting..!</p>';
					header("location:../../theme-setting.php?setting");
					exit();
				}	
			}
			$_SESSION['msg'] = '<p class="alert alert-success shadow my-3" role="alert"> Theme Settings Has Been Saved..!</p>';
			header("location:../../theme-setting.php?setting");
			exit();
		}
	}
	elseif(isset($_POST['forget_password'])){
		$_SESSION['message'] = array();
		$validate = true;
		extract($_POST);
		if ($email=="" || $email==" ") {
			$_SESSION['message']['email_msg'] = "Email Is Required..!";
			$validate = false;
		}

		if ($validate) {
			$query = "SELECT email,password FROM user WHERE email = '{$email}'";
			$result = $database->execute_query($query);
			if ($result->num_rows > 0) {
				$user_data = mysqli_fetch_assoc($result);
				$email = $user_data['email'];
				$password = $user_data['password'];
				if ($send_email->forget_password($email,$password)) {
					$_SESSION['msg'] = '<p class="alert alert-success shadow my-3" role="alert">Your Password Has Been Sent On Your Email..!</p>';
					header("location:../../forget-password.php?forget_password");
					exit();
				}
			}else{
				$_SESSION['msg'] = '<p class="alert alert-danger shadow my-3" role="alert">Invalid Email..!</p>';
				header("location:../../forget-password.php?forget_password");
				exit();
			}
		}else{
			$_SESSION['message']['data'] = $_POST;
			header("location:../../forget-password.php?forget_password");
			exit();
		}
	}
	elseif(isset($_POST['change_password'])){
		$validate = validate_password();
		extract($_POST);
		if ($validate) {
			$query = "UPDATE user SET password = '{$new_password}' WHERE password = '{$old_password}'";
			$result = $database->execute_query($query);
			if ($result) {
				$_SESSION['msg'] = '<p class="alert alert-success shadow my-3" role="alert"> Your Password Has Been Updated Successfully..!</p>';
				header("location:../../change-password.php?change_password");

				exit();
			}else{
				$_SESSION['msg'] = '<p class="alert alert-danger shadow my-3" role="alert"> Could Not Update Password..!</p>';
				$_SESSION['message']['data'] = "Could Not Update Password..!";
				header("location:../../change-password.php?change_password");
				exit();
			}

		}else{
			$_SESSION['message']['data'] = $_POST;
			header("location:../../change-password.php?change_password");
			exit();
		}
	}
	elseif(isset($_REQUEST['get_comments'])){
		extract($_REQUEST);
		?>
		<h6 class="border-start my-3 border-3 px-2 text-secondary lead" style="font-size:18px">Comments</h6>
		<?php 	
			$query = "SELECT pc.*,u.first_name,u.last_name,u.user_image FROM post_comment pc JOIN post p USING(post_id) JOIN USER u USING(user_id)  WHERE p.post_id = {$post_id} AND pc.is_active = 'Active' 
				ORDER BY pc.post_comment_id DESC 
				LIMIT 5";
			$result = $database->execute_query($query);
			if ($result->num_rows > 0) {
				while($comments = mysqli_fetch_assoc($result)){
		?>

		<div class="border p-2 mb-3 rounded message">	
			<div class="d-flex align-items-center" style="">
				<div class="">	
					<img src="uploads/profile-images/<?= $comments['user_image'] ?>" class="rounded-circle" alt="" style="width:45px;height:45px">
				</div>
				<p class="m-0 mx-2 fw-bold"><?= $comments['first_name']." ".$comments['last_name'] ?></p>
			</div>
			<p class="border-start border-3 px-2 my-2" style="font-size: 15px;">	
				<?= $comments['comment'] ?>	
			</p>
			<p>	
				<span class="border-start border-3 px-2 text-secondary lead" style="font-size: 15px;">
		    	<i><?=  date("d M Y  H:i:s A",strtotime($comments['created_at']))  ?></i>
		    </span>
			</p>
		</div>	
		<?php
				}
			}
			else{
				echo "No Comments";
			}
		
	}
?>