#get blog post and user
SELECT * FROM post p JOIN blog b USING(blog_id) JOIN USER USING(user_id)

#get Total Followers of any Blog
SELECT COUNT(*) FROM follow WHERE blog_id = 1

#get feedback 
SELECT * FROM feedback;

#get post with category with attachment
SELECT * FROM attachment a JOIN post p USING(post_id) JOIN post_category pc USING(post_id) JOIN category c USING(category_id)

#get unique categories
SELECT * FROM post p JOIN `post_category` pc USING(`post_id`) JOIN `category` c USING(`category_id`) GROUP BY p.`post_id` HAVING UNIQUE(c.`category`);


