<?php 
	$title = [
		"blog_details" => "Blog",
		"blogs" => "All Blogs",
		"home" => "Home",
		"posts" => "Posts",
		"login"  => "Login Page",
		"register" => "Registration Page",
		"post_details" => "Post Details",
		"following" => "Following Blogs",
		"profile" => "Edit Profile",
		"setting" => "Theme Setting",
		"forget_password" => "Forget Password",
		"change_password" => "Change Password",
	];
?>