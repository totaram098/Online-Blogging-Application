
	<!-- footer -->
	<div class="container-fluid">
		<div class="row justify-content-around bg-info-subtle pt-sm-4">
			<div class="col-lg-3 mb-3">
				<p class="m-0"><i class="fa-solid fa-phone px-2"></i> +92-xxx-xxxxxxx</p>
				<p class="m-0"><i class="fa-solid fa-envelope px-2"></i> official.blog@gmail.com</p>
				<p class="m-0"><i class="fa-solid fa-house px-2"></i> ABC Building Jamshoro,Sindh</p>
			</div>
			<div class="col-lg-3 mb-3">
			  <div class="row align-items-center text-decoration-none">
			  	<?php 
			  		if (isset($_COOKIE['user_data'])) {

			  		
			  	?>
			    <div class="col-sm-6">
			      <a class=" text-dark" href="index.php">Home</a>
			    </div>
			    <div class="col-sm-6">
			      <a class=" text-dark" href="blogs.php?blogs">Latest Blogs</a>
			    </div>
			    <div class="col-sm-6">
			      <a class=" text-dark" href="blogs.php?following">Following</a>
			    </div>
			    <div class="col-sm-6">
			      <a class=" text-dark" href="posts.php?posts">Latest Posts</a>
			    </div>
			    <div class="col-sm-6">
			      <a class=" text-dark" href="assets/common-pages/logout.php">Logout</a>
			    </div>
			    <div class="col-sm-6">
			      <a class=" text-dark" href="theme-setting.php?setting">Theme Setting</a>
			    </div>
			    <div class="col-sm-6">
			      <a class=" text-dark" href="edit-profile.php?profile">Profile</a>
			    </div>
			    <div class="col-sm-6">
			    	<?php if ($user_data['role_type'] == 'Admin'): ?>
			    		
				      <a class=" text-dark" href="admin/index.php">Dashboard</a>
			    	<?php endif ?>
			    </div>
				<?php }else{ ?>
			    <div class="col-sm-6">
			      <a class=" text-dark" href="registration.php?register">Registration</a>
			    </div>
			    <div class="col-sm-6">
			      <a class=" text-dark" href="login.php?login">Login</a>
			    </div>
				<?php } ?>

			  </div>

			</div>
			<div class="col-lg-3 ">
				<span>
					<i class="fa-brands fa-google p-1 fa-2x"></i>
				</span>
				<span>
					<i class="fa-brands fa-x-twitter p-1 fa-2x"></i>
				</span>
				<span>
					<i class="fa-brands fa-youtube p-1 fa-2x"></i>
				</span>
				<span>
					<i class="fa-brands fa-facebook p-1 fa-2x"></i>
				</span>
				<span>
					<i class="fa-brands fa-linkedin p-1 fa-2x "></i>
				</span>
			</div>
			<div class="col-12 mt-3  text-center py-3 border-top border-1 border-dark">
				<p class="p-0 m-0">	
					HIST 21500 All &copy;Copy right Reserved
				</p>
			</div>
		</div>

	</div>
	<!-- /footer -->
	<script src="assets/bootstrap/js/bootstrap.bundle.min.js"></script>
	<script src="validation/registration.js"></script>
	<script src="validation/validate_login.js"></script>
	<script src="validation/feedback.js"></script>
    <script src="assets/common-pages/email_check.js"></script>
	<script>	
        function open_close_profile(){
            var element = document.getElementById("profile");
            element.classList.toggle("d-none");
        }
        function save_feedback(){
        	if (validate_feedback()) {
	        	var form = document.getElementById('feedback_form');
	        	var form_data = new FormData(form);
	        	form_data.append("feedback_form","feedback");
	        	var xhr = new XMLHttpRequest();
	        	xhr.onreadystatechange = function(){
	        		if (xhr.readyState == 4 && xhr.status == 200) {
		       			document.getElementById("feedback_message").innerHTML = xhr.responseText;
		       			form.reset();
	        		}
	        	}
	        	xhr.open("POST","database/user/user-process.php");
	        	xhr.send(form_data);
        	}
        }

      	function get_comments(post_id){
      		var message_container = document.querySelectorAll(".message_container")[0];
      		var xhr = new XMLHttpRequest();
      		xhr.onreadystatechange = function() {
      			if (xhr.readyState == 4 && xhr.status == 200) {
      				message_container.innerHTML = xhr.responseText;
      			}
      		}
      		xhr.open("GET","database/user/user-process.php?get_comments&post_id="+post_id);
      		xhr.send();
      	}
        function leave_comment(){
				var comment = document.querySelector("textarea[name=comment]").value;
				var comment_msg = document.querySelector("#comment_msg");

				is_valid = true;
	        	if (comment=="" || comment==" ") {
					is_valid = false;
					comment_msg.innerHTML = "This Field is required";
				}
				else{
					comment_msg.innerHTML = "";
				}
				if (is_valid) {
		        	var form = document.getElementById('comment_form');
		        	var form_data = new FormData(form);
		        	form_data.append("comment_form","comment");
		        	var xhr = new XMLHttpRequest();
		        	xhr.onreadystatechange = function(){
		        		if (xhr.readyState == 4 && xhr.status == 200) {
			       			document.getElementById("comment_message").innerHTML = xhr.responseText;
			       			get_comments(form_data.get('post_id'));
			       			form.reset();
		        		}
		        	}
		        	xhr.open("POST","database/user/user-process.php");
		        	xhr.send(form_data);
				}
        }
        var follow_status = null;
        function follow_blog(blog_id,user_id,follow){
        		console.log(follow_status);
        		var is_followed = null;
        		if (follow_status == null) {
	        		follow_status = follow;
        		}else{
        			if (follow_status == "Follow") {
        				follow_status = "Unfollow";
        			}else{
        				follow_status = "Follow";
        			}
        		}


    			if (follow_status == "Follow") {
    				is_followed = "Unfollow";
    			}else{
    				is_followed = "Follow";
    			}
        		console.log(follow_status);
        		var xhr = new XMLHttpRequest();
	        	xhr.onreadystatechange = function(){
	        		if (xhr.readyState == 4 && xhr.status == 200) {
	        			document.getElementById('followers').innerHTML = xhr.responseText;
	        			document.getElementById('is_follow').innerHTML = is_followed;
	        		}
	        	}
	        	xhr.open("GET","database/user/user-process.php?follow_blog&user_id="+user_id+"&id="+blog_id+"&follow="+follow_status);
	        	xhr.send();
        }

        function search_post(search){
        	var search_by = document.querySelector("input[name=search_by]:checked").value;
        	if (search_by == "posts") {
        		document.getElementById('search_title').innerHTML = "Post Search : ";
        	}else if(search_by == "blogs"){
        		document.getElementById('search_title').innerHTML = "Blog Search : ";
        	}
        	search = ((search.value) + (window.event.key));
        	var xhr = new XMLHttpRequest();
        	xhr.onreadystatechange = function(){
        		if (xhr.readyState == 4 && xhr.status == 200) {
        			document.querySelectorAll(".search_box")[0].classList.remove('d-none');
        			document.getElementById('show_search_result').innerHTML = xhr.responseText;
        		}
        	}
        	xhr.open("GET","database/user/user-process.php?search_post&search="+search+"&search_by="+search_by);
        	xhr.send();

        }
        function close_searchbox(){
        	document.querySelectorAll(".search_box")[0].classList.add('d-none');
        }

        
		window.onload = function(){
			document.querySelector("#loader_start").classList.add("d-none");
		}
	</script>
</body>
</html>