<?php 
	require("config/database.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Front Panel</title>
	<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/8e452e995a.js" crossorigin="anonymous"></script>
	<style type="text/css">
		*{
			/*padding: 0;
			margin: 0;
			box-sizing: border-box;*/
			font-family: "Poppins", sans-serif;
		 
		}
		.navbar{
			font-weight: 400;
			font-style: normal;
		}
		.sidebar p{
			font-size: 14px;

		}
		.slider_container{
			display: flex;
			overflow: scroll;
		}
		.slider{
			margin: 0 5px;
			width: 250px;
			background: red;
			height: 350px;
		}
		.form-control:focus{
			box-shadow: none;

		}
		.search_box {
		  scrollbar-width: thin;
		}


	</style>
</head>
<body>
	<!-- header -->
	<div class="container-fluid p-0">
		<nav class="navbar poppins-thin navbar-expand-lg  py-3 bg-info-subtle shadow">
		  <div class="container-fluid">
		    <a class="navbar-brand " href="#">
		      <img src="assets/images/logo.png" alt="Logo" width="115" height="60" class="d-inline-block align-text-top m-0">
		    </a>

		    <button style="box-shadow: none; border: none;" class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		      <span class="navbar-toggler-icon"></span>

		    </button>
		    <div class="collapse navbar-collapse" id="navbarSupportedContent">
		      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
		        <li class="nav-item">
		          <a class="nav-link active " aria-current="page" href="#">Home</a>
		        </li>
		        <li class="nav-item">
		          <a class="nav-link " href="#">Blogs</a>
		        </li>
		        <li class="nav-item">
		          <a class="nav-link " href="#">Following</a>
		        </li>
		        <li class="nav-item">
		          <a class="nav-link " href="#">New Blogs</a>
		        </li>
		        <li class="nav-item">
		          <a class="nav-link " href="#">Latest Post</a>
		        </li>
		        <li class="nav-item dropdown">
		          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
		            Category
		          </a>
		          <ul class="dropdown-menu">
		            <li><a class="dropdown-item" href="#">Action</a></li>
		            <li><a class="dropdown-item" href="#">Another action</a></li>
		            <li><hr class="dropdown-divider"></li>
		            <li><a class="dropdown-item" href="#">Something else here</a></li>
		          </ul>
		        </li>
		        <!-- <li class="nav-item">
		          <a class="nav-link disabled" aria-disabled="true">Disabled</a>
		        </li> -->
		      </ul>
		      <div class="d-flex" role="search">
		        <button class="btn btn-outline-primary" style="margin-right: 10px;" type="submit">Register</button>
		        <button class="btn  btn-primary" type="submit">Login</button>
		      </div>
		    </div>
		  </div>
		</nav>
	</div>
	<!-- /header -->
