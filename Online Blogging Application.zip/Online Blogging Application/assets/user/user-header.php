<?php 
	session_start();
	require("config/database.php");
	require ("assets/user/page-title.php");
	$is_valid_page = false;
	foreach ($title as $key => $value) {
		if (isset($_REQUEST[$key])) {
			$page_title = $value;
			$is_valid_page = true;
			if ((!isset($_COOKIE['user_data'])) && !($key == "register" || $key=="login" || $key=="forget_password")) {
				header("location:index.php?msg=Please Login First To See Details..!");
				exit();
			}
			elseif(($key == "register" || $key=="login" || $key=="forget_password")){
				if (isset($_COOKIE['user_data'])) {
					header("location:index.php");
					exit();
				}
			}
		}
	}
	
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?= $page_title??"Home" ?></title>
	<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="assets/loader.css">
	<script src="https://kit.fontawesome.com/8e452e995a.js" crossorigin="anonymous"></script>
	<style type="text/css">
		*{
			/*padding: 0;
			margin: 0;
			box-sizing: border-box;*/
			font-family: "Poppins", sans-serif;
		 
		}
		.navbar{
			font-weight: 400;
			font-style: normal;
		}
		.sidebar p{
			font-size: 14px;

		}
		.slider_container{
			display: flex;
			overflow: scroll;
		}
		.slider{
			margin: 0 5px;
			width: 250px;
			background: red;
			height: 350px;
		}
		.form-control:focus{
			box-shadow: none;

		}
		.search_box {
		  scrollbar-width: thin;
		}

    	.profile_box li:hover{
    		background-color: lightgray;
    	}

	</style>
</head>
<body>
	<!-- loader -->
	<div id="loader_start" class="">
		<div style="position:fixed;display: flex;top:0;left:0;width: 100vw;height: 100%;background-color: rgba(0, 0, 0, 0.9); z-index: 100;text-align: center;align-items: center;justify-content: center;">
		<span class="loader"></span>
		</div>
	</div>
	<!-- /loader -->

	<!-- header -->
	<div class="container-fluid p-0">
		<nav class="navbar poppins-thin navbar-expand-lg  py-3 bg-info-subtle shadow">
		  	<div class="container-fluid">
			    <a class="navbar-brand " href="index.php">
			      <img src="assets/images/logo.png" alt="Logo" width="115" height="60" class="d-inline-block align-text-top m-0">
			    </a>

			    <button style="box-shadow: none; border: none;" class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			      <span class="navbar-toggler-icon"></span>

			    </button>
			    <div class="collapse navbar-collapse" id="navbarSupportedContent">
			      	<ul class="navbar-nav me-auto mb-2 mb-lg-0">
				        <li class="nav-item">
				          <a class="nav-link active " aria-current="page" href="index.php">Home</a>
				        </li>
				        <?php if (isset($_COOKIE['user_data'])): ?>
				        	
					        <li class="nav-item">
					          <a class="nav-link " href="blogs.php?blogs">Blogs</a>
					        </li>
					        <li class="nav-item">
					          <a class="nav-link " href="blogs.php?following">Following</a>
					        </li>
					        <li class="nav-item">
					          <a class="nav-link " href="posts.php?posts">Posts</a>
					        </li>
				        <?php endif ?>
				        <?php if (!$is_valid_page || $page_title=="Home"): ?>
				        	
				        <li class="nav-item">
				          <a class="nav-link " aria-current="page" href="#feedback_form">Feedback</a>
				        </li>
				        <?php endif ?>
			        </ul>
			        <div class="d-flex align-items-center justify-content-end" role="search">
			        	<?php if (isset($_COOKIE['user_data'])): ?>
				        	<div class="profile  position-relative m-1 text-end" style="right: 0px;">
					      		<?php 
					      			$user_data = unserialize($_COOKIE['user_data']);
					      			// extract($user_data);
					      		?>
					      		<span><?= $user_data['first_name']." ".$user_data['last_name'] ?></span>
							    <img src="uploads/profile-images/<?= $user_data['user_image']  ?>" alt="Profile" width="52" height="52" class="rounded-circle" style="cursor: pointer;" onclick="open_close_profile()">
							    <div class="text-start rounded d-none mt-2 position-absolute profile_box shadow bg-light p-2" style="right: 5px;z-index: 10;" id="profile">
							    	<ul class="p-0 m-0" style="list-style: 	none;min-width: 200px;">
							    		<li class="p-2 rounded"><a href="edit-profile.php?profile" class="text-decoration-none text-dark"><i class="fa-solid fa-user mx-2"></i>Profile</a></li>

							    		<?php if ($user_data['role_type'] == "Admin"): ?>
							    		<li class="p-2 rounded"><a href="admin/index.php" class="text-decoration-none text-dark"><i class="fa-solid fa-sliders mx-2"></i>Dashboard</a></li>
							    		<?php endif ?>

							    		<li class=" p-2 rounded mt-1"><a href="theme-setting.php?setting" class="text-decoration-none text-dark"><i class="fa-solid fa-gear mx-2"></i>Theme Setting</a></li>
							    		<li class=" p-2 rounded mt-1"><a href="change-password.php?change_password" class="text-decoration-none text-dark"><i class="fa-solid fa-lock mx-2"></i>Change Password</a></li>
							    		<li class=" p-2 rounded mt-1"><a href="assets/common-pages/logout.php" class="text-decoration-none text-dark"><i class="fa-solid fa-right-from-bracket mx-2"></i>Logout</a></li>
							    	</ul>
							    </div>
							</div>
			        	<?php else: ?>
				        	<div>
						        <a href="registration.php?register" class="btn btn-outline-primary" style="margin-right: 10px;">Register</a>
						        <a href="login.php?login" class="btn btn-primary">Login</a>
				        	</div>
			        	<?php endif ?>
			        	
				      	
			        </div>
			    </div>
		 	</div>
		</nav>

	</div>
	<!-- /header -->
