				<div class="search_here p-0 position-relative">
					<div class="mb-2">
						Search By :  
						<div class="form-check form-check-inline">
						  <input class="form-check-input" type="radio" name="search_by" id="inlineRadio1" value="posts" checked>
						  <label class="form-check-label" for="inlineRadio1">Posts</label>
						</div>
						<div class="form-check form-check-inline">
						  <input class="form-check-input" type="radio" name="search_by" id="inlineRadio2" value="blogs">
						  <label class="form-check-label" for="inlineRadio2">Blogs</label>
						</div>

					</div>
					<div class="input-group mb-3">
					  <input type="text" class="form-control" placeholder="Search " aria-label="Search" aria-describedby="button-addon2" onkeypress="search_post(this)">
					  <!-- <button class="btn btn-outline-secondary" type="button" id="button-addon2">Search</button> -->
					</div>
					<div class="shadow d-none search_box position-absolute rounded border p-2 w-100 bg-white" style="max-height: 80vh;overflow-y: scroll;" >
						<div class="d-flex align-items-center justify-content-between">
							<h3 class="border-start border-2 my-2 px-2" id="search_title">Post Search :</h3>
							<span class="mx-2  px-2 " style="cursor: pointer;" onclick="close_searchbox()"><i class="fa-solid fa-x"></i></span>
						</div>
						<div id="show_search_result" class="w-100">
						</div>
					</div>
				</div>
				<div>
					<!-- latest posts -->
					<h4 class="border-start border-2 px-2 mt-4 mb-3">Latest Posts</h4>
					
				    <?php 
				  		$query = "SELECT p.* FROM post p JOIN blog b USING(blog_id) 
						  		WHERE p.post_status = 'Active' AND b.blog_status = 'Active'
						  		ORDER BY p.post_id DESC LIMIT 5";
				  		$result = $database->execute_query($query);
				  		if ($result->num_rows > 0 ) {
				  			while($latest_posts = mysqli_fetch_assoc($result)){
				  	?>
					<a href="post-details.php?id=<?= $latest_posts['post_id']?>&post_details" class="text-decoration-none text-dark">
						<div class="row my-3 ">
							<div class="col-5">
								<img src="uploads/post-images/<?= $latest_posts['featured_image'] ?>" class="img-fluid">
							</div>

							<div class="col-7 p-0">
								<h5>
									<?= $latest_posts['post_title'] ?>
								</h5>
								<?php 
						    		$post_id = $latest_posts['post_id'];
						    		$category_query = "SELECT * FROM category c JOIN post_category pc USING(category_id) WHERE pc.post_id = '{$post_id}' AND c.category_status = 'Active'";
						    		$category_result = $database->execute_query($category_query);
						    		if ($category_result->num_rows >  0) {
						    			while($categories = mysqli_fetch_assoc($category_result)){
						    	?>
								<span class="badge text-bg-warning">
									<?= $categories['category_title'] ?>
								</span>
						    	<?php			
						    			}
						    		}
						    	?>

								<p class="p-0 m-0">
									 <?= substr($latest_posts['post_summary'],0,100) ?>
								</p>
							</div>
							<div class="col-12  mt-3">
								<div class=" border-bottom border-2"></div>
							</div>
						</div>
					</a>
				  	<?php
				  			}
				  		}
				  	?>
					<!-- latest posts -->
				</div>

				<div>
					<!-- latest Blogs -->
					<h4 class="border-start border-2 px-2 mt-4 mb-3">Latest Blogs</h4>
					<?php 
						$query = "SELECT * FROM blog b JOIN user USING(user_id) 
							WHERE b.blog_status = 'Active'
							ORDER BY b.blog_id DESC LIMIT 4";
						$result = $database->execute_query($query);
						if ($result->num_rows > 0) {
							while ($latest_blogs = mysqli_fetch_assoc($result)) {
					?>
					<a href="blog-details.php?id=<?= $latest_blogs['blog_id'] ?>&blog_details" class="text-decoration-none text-dark">
						<div class="row my-3 ">
							<div class="col-5">
								<img src="uploads/blog-images/<?= $latest_blogs['blog_background_image']?>" class="img-fluid">
							</div>

							<div class="col-7 p-0">
								<h5>
									<?= $latest_blogs['blog_title']?>
								</h5>
								
								<span style="font-size: 13px;">
									By : 
									<i>
										<?= $latest_blogs['first_name']." " .$latest_blogs['last_name']?>
									</i>
								</span>
								<br>
								<span style="font-size: 13px;">
									Created At : 
									<i>
										<?= date("d M Y H:i:s A",strtotime($latest_blogs['created_at']))?>
									</i>
								</span>
							</div>
							<div class="col-12  mt-3">
								<div class=" border-bottom border-2"></div>
							</div>
						</div>
					</a>
					<?php
							}
						}
					?>
					
					<!-- latest Blogs -->
				</div>	
				<div>
					<h4 class="border-start border-2 px-2 mt-4 mb-3">Categories</h4>
					<?php 
			    		$category_query = "SELECT * FROM category WHERE category_status = 'Active' LIMIT 50";
			    		$category_result = $database->execute_query($category_query);
			    		if ($category_result->num_rows >  0) {
			    			while($categories = mysqli_fetch_assoc($category_result)){
			    	?>
					<span class="badge text-bg-warning">
						<?= $categories['category_title'] ?>
					</span>
			    	<?php			
			    			}
			    		}
			    	?>
				</div>	