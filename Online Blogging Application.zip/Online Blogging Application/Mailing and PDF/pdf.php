<?php 
	require_once("fpdf/fpdf.php");
	extract($user_data);
	$full_name = $first_name." ".$last_name;
	$profile = "../../uploads/profile-images/".$user_image;
	$pdf = new FPDF();
	$pdf->AddPage();
	$pdf->SetFont('Times',"B");
	$pdf->Image("../../assets/images/logo.png",6,10,20,12);
	$pdf->Cell(0,10,"Account Information","B",1,"C");
	$pdf->SetFont('Times',"");
	$pdf->Image($profile,90,25,30,30);
	$pdf->setY(60);
	$pdf->Cell(0,10,("Full Name          :  ".$full_name),"",1);
	$pdf->Cell(0,10,("Email              :  ".$email),"",1);
	$pdf->Cell(0,10,("Gender             :  ".$gender),"",1);
	$pdf->Cell(0,10,("Role               :  ".$role_type),"",1);
	$pdf->Cell(0,10,("Date Of Birth      :  ".$date_of_birth),"",1);
	$pdf->Cell(0,10,("Address            :  ".$address),"",1);
	$pdf->Cell(0,10,("Account Approval   :  ".$is_approved),"",1);
	$pdf->Cell(0,10,("Account Status     :  ".$is_active),"",1);
	$pdf->Cell(0,10,("Password           :  ".$password),"",1);
	if (!is_dir('../../uploads/user-information-pdf')) {
		mkdir('../../uploads/user-information-pdf');
	}
	$user_pdf = '../../uploads/user-information-pdf/Account_Information_'.$user_id.'.pdf';
	$pdf->Output("F",$user_pdf);

?>