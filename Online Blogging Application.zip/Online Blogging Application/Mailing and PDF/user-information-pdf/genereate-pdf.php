<?php 
	class Generate_PDF{
		function generate_pdf($user_id){
			require('pdf.php');
		}
	}
	$generate_pdf = new Generate_PDF();
	$generate_pdf->generate_pdf(3);
?>