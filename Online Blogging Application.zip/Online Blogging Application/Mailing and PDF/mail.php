<?php 
	require('PHPMailer.php');
	$mail->addAddress("totaramm2020@gmail.com","RAM");
	//Set the subject line
	$mail->Subject = "Account Registration";
	//Read an HTML message body

	$message = '<h5 style="text-align: center;">Thank You For Your Registration.</h5>
	<p style="text-align: center;">
		You Can Find Your Whole Information In  Given PDF.
	</p>';
	$mail->isHTML();
	$mail->Body = $message;

	//send the message, check for errors
	if ($mail->send()) {
	   echo "Send";
	}
	else{
	   echo "Probelm";
	}
?>