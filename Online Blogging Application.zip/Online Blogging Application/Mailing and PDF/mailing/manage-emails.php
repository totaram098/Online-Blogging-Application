<?php 
	// require("../../config/database.php");
	class Manage_Email{
		public $PHPMailer;
		public $user_information;
		public $database;
		public function __construct($mail,$database){
			$this->PHPMailer  = $mail;
			$this->database  = $database;
		}
		function registration($user_id,$state){
			$query = "SELECT * FROM user u JOIN role USING(role_id) WHERE u.user_id = {$user_id}";
			$result = $this->database->execute_query($query);
			if ($result->num_rows > 0) {
				$user_data = mysqli_fetch_assoc($result);

				$this->generate_pdf($user_data);

				$user_email = $user_data['email'];
				$user_name = $user_data['first_name']." ".$user_data['last_name'];
			
				$this->PHPMailer->addAddress($user_email,$user_name);
				if ($state == "register") {
					$title = "Thank You For Your Registration.";
					$this->PHPMailer->Subject = "Account Registration";
				}
				elseif ($state == "update") {
					$title = "Account Updated";
					$this->PHPMailer->Subject = "Account Updated";
				}

				$message = '<h5 style="text-align: center;">'.$title .'</h5>
				<p style="text-align: center;">
					You Can Find Your Whole Information In  Given PDF.
				</p>';
				$user_pdf = '../../uploads/user-information-pdf/Account_Information_'.$user_id.'.pdf';
				$this->PHPMailer->addAttachment($user_pdf,"Account Information"); 
				$this->PHPMailer->isHTML();
				$this->PHPMailer->Body = $message;
				$this->PHPMailer->send();

				$admin = "SELECT * FROM user u JOIN role r USING(role_id) WHERE r.role_type = 'Admin'";
				
				$admin_result = $this->database->execute_query($admin);
				if ($admin_result->num_rows>0) {
					$this->PHPMailer->ClearAddresses($user_email,$user_name);
					while($admins = mysqli_fetch_assoc($admin_result)){
						$admin_email = $admins['email'];
						$admin_name = $admins['first_name'].' '.$admins['last_name'];
						$this->PHPMailer->addBcc($admin_email,$admin_name);
					}
					$this->PHPMailer->Subject = "New User Registration";
					$message = '<h5 style="text-align: center;">New Account Details</h5>
					<p style="text-align: center;">
						<b>Name :</b>'.$user_data['first_name'].' '.$user_data['last_name'].'<br>
						<b>Email :</b>'.$user_data['email'].'<br>
						<b>Role :</b>'.$user_data['role_type'].'<br>
						<b>Active Status :</b>'.$user_data['is_active'].'<br>
						<b>Approval Status :</b>'.$user_data['is_approved'].'
					</p>';
					$this->PHPMailer->isHTML();
					$this->PHPMailer->Body = $message;
					$this->PHPMailer->send();
				}

			}else{
				echo "Wrong User_id Provided";
			}
		}
		function account_status($user_id,$value){

			$query = "SELECT * FROM user WHERE user_id = {$user_id}";
			$result = $this->database->execute_query($query);
			if ($result->num_rows > 0) {
				$user_data = mysqli_fetch_assoc($result);


				$user_email = $user_data['email'];
				$user_name = $user_data['first_name']." ".$user_data['last_name'];
			
				$this->PHPMailer->addAddress($user_email,$user_name);
				if ($value == 'Active' || $value == 'InActive') {
					$value = ($value == 'Active')?"Activated":"Deactivated..!";
					$this->PHPMailer->Subject = "Account Status Information";
				}else{
					$this->PHPMailer->Subject = "Account Approval Information";
				}

				$message = '<h5 style="text-align: center;">Dear, User.</h5>
				<p style="text-align: center;">
					Your Account Has Been '.$value.'</p>';
				$this->PHPMailer->isHTML();
				$this->PHPMailer->Body = $message;

				$this->PHPMailer->send();
			}
		}
		function forget_password($email,$password){

			$this->PHPMailer->addAddress($email);
			
			$this->PHPMailer->Subject = "Password Recovered";

			$message = '<h5 style="text-align: center;">Account Password</h5>
			<p style="text-align: center;">
				Your Account Password Is : '.$password.'</p>';
			$this->PHPMailer->isHTML();
			$this->PHPMailer->Body = $message;

			if ($this->PHPMailer->send()) {
				return true;
			}else{
				return false;
			}
		
		}
		function feedback($feedback_id){
			$query = "SELECT * FROM user_feedback WHERE feedback_id = {$feedback_id}";
			$result = $this->database->execute_query($query);
			if ($result->num_rows > 0) {
				$feedback_data = mysqli_fetch_assoc($result);

				$query = "SELECT * FROM user u JOIN role r USING(role_id) WHERE r.role_type = 'Admin'";
				$result = $this->database->execute_query($query);
				if ($result->num_rows > 0) {
					while ($admins = mysqli_fetch_assoc($result)) {
						$user_name = $admins['first_name']." ".$admins['last_name'];
						$this->PHPMailer->addBCC($admins['email'],$user_name);
					}
					$this->PHPMailer->Subject = "Feedback Notfication";

					$message = '<div style="border: 1px solid black; padding: 5px;">
						<h1 style="text-align: center;">New Feedback</h1>
						<h3>Name : '.$feedback_data['user_name'].'</h3>
						<h3>Email : '.$feedback_data['user_email'].'</h3>
						<p>'.$feedback_data['feedback'].'
						</p>
					</div>';
					$this->PHPMailer->isHTML();
					$this->PHPMailer->Body = $message;

					$this->PHPMailer->send();
				}
			}
		}
		function post_update($post_id,$blog_id){
			$query = "SELECT * FROM post WHERE post_id = '{$post_id}'";
			$result = $this->database->execute_query($query);
			if ($result->num_rows > 0) {
				$post_data = mysqli_fetch_assoc($result);
				$query = "SELECT u.first_name,u.last_name,u.email,b.blog_title FROM blog b JOIN following_blog fb ON fb.blog_following_id = b.blog_id 
					JOIN USER u ON u.user_id = fb.follower_id
					WHERE fb.blog_following_id  = {$blog_id}";
				$result = $this->database->execute_query($query);
				if ($result->num_rows > 0) {
					while ($users = mysqli_fetch_assoc($result)) {
						$user_name = $users['first_name']." ".$users['last_name'];
						$this->PHPMailer->addBcc	($users['email'],$user_name);
					}
					$this->PHPMailer->Subject = "New Post Notfication";

					$message = '<div style="border: 1px solid black; padding: 5px;text-align: center;">
						<h1 style="">New Post </h1>
						<img src="..uploads/post-images/'.$post_data['featured_image'].'" alt="" style="max-width: 95%;">
						<h3>'.$users['blog_title'].'</h3>
						<h3>'.$post_data['post_title'].'</h3>
						<p>'.substr($post_data['post_summary'], 0,150).'
						</p>
						<a href="www.google.com">See Details</a>
					</div>';
					$this->PHPMailer->isHTML();
					$this->PHPMailer->Body = $message;

					$this->PHPMailer->send();
				}	
			}
		}
		function generate_pdf($user_data){
			require('../../Mailing and PDF/pdf.php');
		}
	}
	$send_email = new Manage_Email($mail,$database);
?>