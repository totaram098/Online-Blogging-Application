<?php 
	require_once("database-credentials.php");
	mysqli_report(false);
	class Database{
		public $connection;
		public $result;
		public $query;
		function __construct($hostname,$username,$password,$database){
			$this->connection = mysqli_connect($hostname,$username,$password,$database) or die("Connection Failed<br>Message : ".mysqli_connect_error());
		}
		function execute_query($query){
			$this->query = $query;
			$this->result = mysqli_query($this->connection, $this->query);
			return $this->result;
		}
	}
	$database = new Database(HOSTNAME,USERNAME,PASSWORD,DATABASE);
?>