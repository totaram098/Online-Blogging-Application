<?php 
	include("assets/user/user-header.php");
?>
<?php
	if (!(isset($_GET['blogs']) || isset($_GET['following'])) ) {
	?>
	<script>
		window.location.href = "index.php";
	</script>
<?php } ?>	
	<!-- content -->
	<div class="container-fluid my-5">

		<div class="row">
			<div class="col-md-8 p-0">
				<!-- post details -->
				<div class="card h-100  border border-0 mb-3">

					<!-- <div class="border"></div> -->
				  	<div class="card-body rounded shadow  m-md-2 my-2 p-sm-4">
					    <h1 class="card-title border-start border-5 px-2 mb-4">
					    	<?= isset($_REQUEST['following'])?"Following":"" ?>
						    BLOGS
						</h1>
					    <div class="row mb-4">
					    	<?php 
					    		$blogs_per_page = 9;
					    		$page = "blogs";
					    		$user_id = $user_data['user_id'];
					    		$start = $_REQUEST['page']??1;
					    		$current_page = $start;
					    		$start = ($start-1) * $blogs_per_page;
					    		if (isset($_REQUEST['following'])) {
					    			$page = "following";
					    			$query = "SELECT b.*,u.first_name,u.last_name FROM blog b JOIN USER u USING(user_id)
										WHERE b.blog_id IN (SELECT blog_following_id FROM following_blog  WHERE follower_id = {$user_id}
										GROUP BY blog_following_id)
										AND b.blog_status = 'Active'
										ORDER BY b.blog_id DESC
										LIMIT $start,$blogs_per_page";
					    		}
					    		else{
									$query = "SELECT b.*,u.first_name,u.last_name FROM blog b JOIN USER u USING(user_id)
										WHERE b.blog_status = 'Active'
										ORDER BY b.blog_id DESC
										LIMIT $start,$blogs_per_page 
										";
					    		}
								$result = $database->execute_query($query);
								echo mysqli_error($database->connection);
								if ($result->num_rows > 0) {
									while($blogs = mysqli_fetch_assoc($result)){
										extract($blogs);
							?>

					    	<div class="col-md-6 col-lg-4 p-2">
					    		<a href="blog-details.php?id=<?= $blog_id ?>&blog_details" class="text-decoration-none">
						    		<div class="card h-100 shadow border border-0">
									  <img src="uploads/blog-images/<?= $blog_background_image ?>" class="card-img-top" alt="...">
									  <div class="card-body">
									    <p class="p-0 m-0 ">

										   	 <span class="badge text-bg-primary">
										   	 	<?php 
										   	 		$followers = "SELECT COUNT(follow_id) followers FROM following_blog WHERE blog_following_id = {$blog_id}";
										   	 		$followers_result = $database->execute_query($followers);
										   	 		$follower = mysqli_fetch_assoc($followers_result);
										   	 		$follower = $follower['followers'];
										   	 	?>
										    	Followers <?= $follower ?>
										    </span>
										</p>
									    <h5 class="card-title p-0 m-0 my-2"><?= $blog_title ?></h5>
									   <p class="p-0 m-0">
									   	 <span class="card-title text-secondary" style="font-size: 12px;"><i>By : <?= $first_name." ".$last_name ?></i></span>
									   </p>
									   <p class="p-0 m-0">
									   	 <span class="card-title text-secondary" style="font-size: 12px;"><i>Created On : <?=  date("d M Y  H:i:s A",strtotime($created_at))  ?></i></span>
									   </p>

									  </div>
									</div>
					    		</a>
					    	</div>
							<?php
									}
								}	
								else{
									echo "<h5 class='text-center'>No Blog Found..!</h5>";
								}	
					    	?>
					    	
					    </div>
					    <?php 	
					    	if (isset($_REQUEST['following'])) {
					    		$user_id = $user_data['user_id'];
				    			$count_blogs = "SELECT COUNT(fb.blog_following_id) total_blogs FROM blog b JOIN following_blog fb ON fb.blog_following_id = b.blog_id JOIN USER u ON fb.follower_id = u.user_id
								WHERE fb.follower_id = {$user_id} AND b.blog_status = 'Active'";
					    	}
				    		else{
				    			$count_blogs = "SELECT COUNT(blog_id) total_blogs FROM blog WHERE blog_status = 'Active'";
				    		}
				    		$count_result = $database->execute_query($count_blogs);
				    		if ($count_result->num_rows > 0 ) {
				    			$counts = mysqli_fetch_assoc($count_result);
				    			if ($counts['total_blogs'] > 0) {
					    ?>
					    <nav aria-label="Page navigation example">
							<ul class="pagination justify-content-center">
						
					    <?php			
					    			$total_blogs = $counts;
					    			$total_blogs = $total_blogs['total_blogs'];
						    		$pages = ceil($total_blogs/$blogs_per_page);
									$prev = ($current_page==1)?"disabled":"";
									$next = ($current_page==$pages)?"disabled":"";

						?>
								<li class="page-item  <?= $prev ?>">
							      <a class="page-link"  href="blogs.php?<?= $page;?>&page=<?= ($current_page-1) ?>">Previous</a>
							    </li>
						<?php    		
						    		for ($i=1; $i <= $pages ; $i++) { 
						?>

							 	<li class="page-item">
							 		<a class="page-link" href="blogs.php?<?= $page;?>&page=<?= $i ?>">
							 			<?= $i ?>		
								 	</a>
							 	</li>
						<?php    			
						    		}
						?>
								<li class="page-item <?= $next ?> ">
							      <a class="page-link"  href="blogs.php?<?= $page;?>&page=<?= ($current_page+1) ?>">Next</a>
							    </li>
							 </ul>
						</nav>
						<?php    
								}		
					    	}
					    ?>
					    
				 	</div>
				</div>
				<!--/ post details -->
			</div>
			<div class="col-md-4 sidebar">
				<?php 
					include('assets/user/sidebar.php');
				?>	
			</div>
		</div>
	</div>
	<!-- content -->
<?php 
	include("assets/user/user-footer.php");
?>	