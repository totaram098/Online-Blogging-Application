<?php 
	include("assets/user/user-header.php");
	$file = explode("\\", __FILE__);
	$is_home = end($file);
	if (!$is_valid_page) {
		if ($is_home != "index.php") {
			header("location:error.php");
		}
	}

?>
	<!-- content -->

	<div class="container-fluid my-5">
		<p class="text-danger">
			<?= $_GET['msg']??""; ?>
		</p>
		<div class="row">
			<div class="col-md-8">
				<div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
				  <div class="carousel-inner">
				  	<?php 
				  		$query = "SELECT p.* FROM post p JOIN blog b USING(blog_id) 
						  		WHERE p.post_status = 'Active' AND b.blog_status = 'Active'
						  		ORDER BY p.post_id DESC LIMIT 5";
				  		$result = $database->execute_query($query);
				  		if ($result->num_rows > 0 ) {
				  			$slider_active = true;
				  			while($new_posts = mysqli_fetch_assoc($result)){
				  	?>
				    <a href="post-details.php?id=<?= $new_posts['post_id'] ?>&post_details">
				    	<div class="carousel-item <?= ($slider_active)?'active':"" ?>">
					      	<img src="uploads/post-images/<?= $new_posts['featured_image'] ?>" class="d-block w-100 h-100" alt="...">
				            <div class="carousel-caption bg-light rounded text-dark" style="--bs-bg-opacity: .5;">
						        <h5><?= $new_posts['post_title'] ?></h5>
						        <div class="d-none d-md-block">
						        	<p>
						        		<?php 
								    		$post_id = $new_posts['post_id'];
								    		$category_query = "SELECT * FROM category c JOIN post_category pc USING(category_id) WHERE pc.post_id = '{$post_id}' AND c.category_status = 'Active'";
								    		$category_result = $database->execute_query($category_query);
								    		if ($category_result->num_rows >  0) {
								    			while($categories = mysqli_fetch_assoc($category_result)){
								    	?>
										<span class="badge text-bg-warning">
											<?= $categories['category_title'] ?>
										</span>
								    	<?php			
								    			}
								    		}
								    	?>
							        </p>
							        <p>
								        <?= substr($new_posts['post_summary'],0,180) ?>

							    	</p>
						        </div>
						    </div>
					    </div>
				    </a>

				  	<?php
				  			$slider_active = false;
				  			}
				  		}
				  	?>
				  </div>
				</div>

				<!-- Top Blogs -->
				<h1 class=" mb-3 mt-5 border-start border-5 px-2">Top Blogs</h1>
				<div class="row">
					<?php 
						$query = "SELECT u.first_name,u.last_name,b.*,COUNT(fb.follow_id) follower FROM blog b 
							LEFT JOIN following_blog fb ON fb.blog_following_id = b.blog_id 
							JOIN USER u USING(user_id)
							WHERE b.blog_status = 'Active'
							GROUP BY b.blog_id
							ORDER BY follower DESC 
							LIMIT 3";
						$result = $database->execute_query($query);	
						if ($result->num_rows > 0) {
							while($blogs = mysqli_fetch_assoc($result)){
								extract($blogs);
					?>
					<div class="col-lg-4 my-2">
						<a href="blog-details.php?id=<?= $blog_id; ?>&blog_details" class="text-decoration-none">
							<div class="card h-100 shadow">
							  <img src="uploads/blog-images/<?= $blog_background_image?>" class="card-img-top h-100" alt="..." >
							  <div class="card-body">
							    <h5 class="card-title"><?= $blog_title ?></h5>
							    <p class="card-text">

									<span class="badge text-bg-primary p-2 my-2"><?= $follower ?> Followers</span>
									<br>
								    <i>Created By : <?= $first_name. " " .$last_name ?></i>
								</p>
							  </div>
							</div>
						</a>
					</div>
					<?php			
							}
						}
					?>
					
				</div>
				<!-- Top Blogs -->

				<!-- Top Category -->
				<h1 class=" mt-5 mb-3 border-start border-5 px-2">Top Categories</h1>
				<div class="row">
					<?php 
						$query = "SELECT c.category_id FROM post_category pc LEFT JOIN category c ON pc.category_id = c.category_id
							WHERE c.category_status = 'Active'
							GROUP BY c.category_title
							ORDER BY COUNT(pc.category_id) DESC
							LIMIT 3";

						$result = $database->execute_query($query);
						if ($result->num_rows > 0) {
							while($top_categories = mysqli_fetch_assoc($result)){

								$category_id = $top_categories['category_id'];
								$post_query = "SELECT * FROM post p JOIN post_category pc USING(post_id) WHERE pc.category_id = '{$category_id}' ORDER BY p.post_id DESC";
								$post_result = $database->execute_query($post_query);
								if ($post_result->num_rows > 0) {
									$posts = mysqli_fetch_assoc($post_result);
					?>

					<div class="col-lg-4 my-2">
						<a href="post-details.php?id=<?= $posts['post_id']; ?>&post_details" class="text-decoration-none">
							<div class="card h-100 shadow">
							  <img src="uploads/post-images/<?= $posts['featured_image'] ?>" class="card-img-top" alt="...">
							  <div class="card-body">
							    <h5 class="card-title"><?= $posts['post_title'] ?></h5>
							    <p class="card-text">
							    	<?php 
							    		$post_id = $posts['post_id'];
							    		$category_query = "SELECT * FROM category c JOIN post_category pc USING(category_id) WHERE pc.post_id = '{$post_id}' AND c.category_status = 'Active'";
							    		$category_result = $database->execute_query($category_query);
							    		if ($category_result->num_rows >  0) {
							    			while($categories = mysqli_fetch_assoc($category_result)){
							    	?>
									<span class="badge text-bg-warning">
										<?= ($categories['category_id']== $category_id)? '<i class="badge text-bg-success">Top</i>' :""?>
										
										<?= $categories['category_title'] ?>
									</span>
							    	<?php			
							    			}
							    		}
							    	?>
									<br>
								    <?= substr($posts['post_summary'],0,100) ?>
								    <?php $length = strlen($posts['post_summary']) ?>
								    <?= (($length>100)?"...":"") ?>

								</p>
							  </div>
							</div>
						</a>
					</div>

					<?php
								
								}
							}
						}else{
							echo "<p class='text-center'>No Any Top Category Yet..!</p>";
						}	
					?>
				</div>
				<!-- Top Category -->
				
			</div>
			<div class="col-md-4 sidebar">
				<?php 
					include('assets/user/sidebar.php');
				?>	
			</div>
		</div>
		<div class="row mt-3">
			<div class="col-md-8">
				<h1 class=" mt-5 mb-3 border-start border-5 px-2">Feedback</h1>
				<div id="feedback_message">	
				</div>
				<form id="feedback_form">
					<div class="row">
						<div class="col-md-6">
							<div class="form-floating mb-3">
							<?php if (isset($_COOKIE['user_data'])): ?>
							<?php $user_data = unserialize($_COOKIE['user_data']);?>
								<input type="hidden" name="user_id" value="<?= $user_data['user_id'] ?>">
								<input type="hidden" name="user_name" value="<?= $user_data['first_name']." ".$user_data['last_name'] ?>">
								<input type="hidden" name="user_email" value="<?= $user_data['email'] ?>">
							<?php endif ?>
							  <input type="text" class="form-control" id="floatingInput" placeholder="Full Name" name="user_name" <?= isset($_COOKIE['user_data'])?"disabled":"" ?> value='<?= isset($_COOKIE['user_data'])? $user_data['first_name']." ".$user_data['last_name'] :"" ?>' >
							  <label for="floatingInput">Full Name</label>
							</div>
							<p class="px-1 text-danger mb-3" style="font-size:12px" id="user_name_msg">
							</p>

						</div>
						<div class="col-md-6">
							<div class="form-floating mb-3">
								<input type="email" class="form-control" id="floatingInput" placeholder="name@example.com" name="user_email" <?= isset($_COOKIE['user_data'])?"disabled":"" ?> value='<?= isset($_COOKIE['user_data'])? $user_data['email'] :"" ?>' >
							  <label for="floatingInput">Email address</label>
							</div>
							<p class="px-1 text-danger mb-3" style="font-size:12px" id="user_email_msg">
							</p>

						</div>
						<div class="col-12">
							<div class="form-floating mb-3">
							  <textarea class="form-control" placeholder="Feedback Here" id="floatingTextarea" name="feedback" style="height: 100px;"></textarea>
							  <label for="floatingTextarea">Feedback Here</label>
							</div>
							<p class="px-1 text-danger mb-3" style="font-size:12px" id="feedback_msg">
							</p>
						</div>
						<div class="col-12">
							<div class="d-flex justify-content-end">
								<div>
									<input type="button" name="feedbackbtn" value="Submit" class="form-control btn btn-primary" onclick="save_feedback()">
								</div>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- content -->

<?php 
	include("assets/user/user-footer.php");
?>	