<?php 
	include("assets/user/user-header.php");
?>
	<div class="container">
		<?php 
			if (isset($_SESSION['message'])) {
				extract($_SESSION['message']);
				if (isset($data)) {
					extract($data);
				}
			}
		?>
		<div class="row justify-content-center p-0 m-0 align-items-center my-3" style="min-height: 70vh;">
			<div class="col-md-6 col-sm-10">
			<h1 class="border-start border-5 bg-secodary shadow px-3 py-3 rounded mb-3">LOGIN HERE</h1>
			<?= $_SESSION['msg']?? "" ?>
			<form action="database/user/user-process.php" onsubmit="return validate_login();" method="POST" class="shadow p-sm-3 p-2 rounded">
	  				<div class="row justify-content-center">
	  					<div class="col-11">
							<div class="form-floating ">
							  <input type="text" class="form-control" id="floatingInput" placeholder="example123@gmail.com" name="email" value="<?= $email??""; ?>">
							  <label for="floatingInput">Email</label>
							</div>
							<p class="px-1 text-danger mb-3" style="font-size:12px" id="email_msg">
								<?= $email_msg ?? "";?>
							</p>
	  					</div>
	  				</div>
	  				<div class="row justify-content-center">
	  					<div class="col-11">
	  						<div class="form-floating">
							  <input type="password" class="form-control" id="floatingInput" placeholder="Password" name="password" value="<?= $password??""; ?>">
							  <label for="floatingInput">Password</label>
							</div>
							<p class="px-1 text-danger mb-3" style="font-size:12px" id="password_msg">
								<?= $password_msg ?? "";?>
							</p>
	  					</div>
	  				</div>
	  				<div class="row justify-content-center">
	  					<div class="col-11">
	  						<p><a href="forget-password.php?forget_password">Forget Password</a> </p>
	  					</div>
	  				</div>

	  				<div class="row justify-content-center">
	  					<div class="col-11">
	  						<div class="row justify-content-end">
			  					<div class="col-md-3 col-sm-6 mb-2 col-12">
			  						<input type="reset" name="reset" value="Clear" class="form-control btn btn-danger">
			  					</div>
			  					<div class="col-md-3 col-sm-6 col-12">
			  						<input type="Submit" name="login" value="Login" class="form-control btn btn-primary">
			  					</div>
							</div>
	  					</div>
	  				</div>
	  			</form>
  			<?php 
				if (isset($_SESSION['message'])) {
					session_destroy();
				}
			?>
			</div>
		</div>
	</div>
<?php 
	include("assets/user/user-footer.php");
?>