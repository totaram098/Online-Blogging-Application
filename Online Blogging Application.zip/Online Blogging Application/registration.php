<?php 
	include("assets/user/user-header.php");
?>
	<div class="container">
		<?php 
			if (isset($_SESSION['message'])) {
				extract($_SESSION['message']);
				if (isset($data)) {
					extract($data);
				}
			}
		?>
		<div class="row justify-content-center p-0 m-0 align-items-center mt-3" style="min-height: 80vh;">
			<div class="col-md-8 col-sm-10">
			<h1 class="border-start border-5 bg-secodary text- shadow px-3 py-3 rounded mb-3">REGISTER HERE</h1>
			<?= $_SESSION['msg']?? "" ?>
			<form action="database/user/user-process.php" onsubmit="return validate_registration();" method="POST" class="shadow my-3 p-sm-3 p-2 rounded" enctype="multipart/form-data">
				<div class="row">
					<div class="col-lg-6">
						<div class="form-floating">
						  <input type="text" class="form-control" name="first_name" id="floatingInput" placeholder="Totaram" value="<?= $first_name??""; ?>">
						  <label for="floatingInput">First Name</label>
						</div>
						<p class="px-1 text-danger mb-3" style="font-size:12px" id="first_name_msg">
							<?= $first_name_msg ?? "";?>
						</p>
					</div>
					<div class="col-lg-6">
						<div class="form-floating">
						  <input type="text" class="form-control" id="floatingInput" name="last_name" placeholder="Meghwar" value="<?= $last_name??""; ?>">
						  <label for="floatingInput">Last Name</label>
						</div>

						<p class="px-1 text-danger mb-3" style="font-size:12px" id="last_name_msg">
							<?= $last_name_msg ?? "";?>
						
						</p>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-6">
						<span class="mx-2">
							<b>Gender </b>
						</span>
						<br>
						<div class="mx-2 form-check form-check-inline">
						  <input class="form-check-input" type="radio" id="inlineCheckbox1" value="Male" name="gender" <?= (isset($gender) && $gender=='Male')?"checked": "";?> >
						  <label class="form-check-label" for="inlineCheckbox1" >Male</label>
						</div>
						<div class="form-check form-check-inline">
						  <input class="form-check-input" type="radio" id="inlineCheckbox2" value="Female" name="gender"  <?= (isset($gender) && $gender=='Female')?"checked": "";?>>
						  <label class="form-check-label" for="inlineCheckbox2">Female</label>
						</div>

						<p class="px-1 text-danger mb-3" style="font-size:12px" id="gender_msg">
							<?= $gender_msg ?? "";?>
						</p>
					</div>
					<div class="col-lg-6">
						<div class="form-floating ">
						  <input type="text" class="form-control" id="floatingInput" placeholder="example123@gmail.com" name="email" value="<?= $email??""; ?>"  onblur="check_email(this,'User')">
						  <label for="floatingInput">Email</label>
						</div>
						<p class="px-1 text-danger mb-3" style="font-size:12px" id="email_msg">
							<?= $email_msg ?? "";?>
						</p>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-6">
						<div class="form-floating">
						  <input type="date" class="form-control" id="floatingInput" placeholder="Date of Birth" name="date_of_birth" value="<?= $date_of_birth??""; ?>">
						  <label for="floatingInput">Date Of Birth</label>
						</div>
						<p class="px-1 text-danger mb-3" style="font-size:12px" id="date_of_birth_msg">
							<?= $date_of_birth_msg ?? "";?>
						</p>
					</div>
					<div class="col-lg-6">
						<div class="form-floating">
						  <input type="file" class="form-control" id="floatingInput" placeholder="example123@gmail.com" name="user_image" accept="image/*">
						  <label for="floatingInput">Profile Image</label>
						</div>
						<p class="px-1 text-danger mb-3" style="font-size:12px" id="user_image_msg">
							<?= $user_image_msg ?? "";?>
						</p>
					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<div class="form-floating">
						  <input type="text" class="form-control" id="floatingInput" placeholder="Address" name="address" value="<?= $address??""; ?>">
						  <label for="floatingInput">Address</label>
						</div>
						<p class="px-1 text-danger mb-3" style="font-size:12px" id="address_msg">
							<?= $address_msg ?? "";?>
						</p>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-6">
						<div class="form-floating">
						  <input type="password" class="form-control" id="floatingInput" placeholder="Password" name="password" value="<?= $password??""; ?>">
						  <label for="floatingInput">Password</label>
						</div>
						<p class="px-1 text-danger mb-3" style="font-size:12px" id="password_msg">
							<?= $password_msg ?? "";?>
						</p>
					</div>
					<div class="col-lg-6">
						<div class="form-floating">
						  <input type="password" class="form-control" id="floatingInput" placeholder="Confirm Password" name="confirm_password" value="<?= $confirm_password??""; ?>">
						  <label for="floatingInput">Confirm Password</label>
						</div>
						<p class="px-1 text-danger mb-3" style="font-size:12px" id="confirm_password_msg">
							<?= $confirm_password_msg ?? "";?>
						</p>
					</div>
				</div>
				<div class="row justify-content-end">
					<div class="col-md-3 col-sm-6 mb-2">
						<input type="reset" name="reset" value="Clear" class="form-control btn btn-danger">
					</div>
					<div class="col-md-3 col-sm-6">
						<input type="Submit" name="register" value="Register" class="form-control btn btn-primary" id="submit_button">
					</div>
				</div>
			</form>
			</div>
  			<?php 
				if (isset($_SESSION['message'])) {
					session_destroy();
				}
			?>
		</div>
	</div>
<?php 
	include("assets/user/user-footer.php");
?>