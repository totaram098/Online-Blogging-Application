<?php 
	include("assets/user/user-header.php");
?>
	<div class="container">
		<?php
			if (!isset($_GET['setting'])) {
			?>
			<script>
				window.location.href = "index.php";
			</script>
			<?php

			}
			$user_id = $user_data['user_id'];
			$settings = array();
			$is_active = "Active";
			$is_theme_set = "no";
			$query = "SELECT * FROM setting WHERE user_id = {$user_id}";
			$result = $database->execute_query($query);
			if ($result->num_rows > 0) {
				while($theme_setting = mysqli_fetch_assoc($result)){
					$key = $theme_setting['setting_key'];
					$value = $theme_setting['setting_value'];
					$settings[$key] = $value;
					$is_active = $theme_setting['setting_status'];
				}
				$is_theme_set = "yes";
			}


			if ($is_theme_set == "yes") {
				$title_color = $settings['title_color'];
				$title_font_style = $settings['title_font_style'];
				$title_bg_color = $settings['title_background_color'];
				$title_font_size = $settings["title_font_size"];

				$description_color = $settings["description_color"];
				$description_font_style = $settings["description_font_style"];
				$description_bg_color = $settings["description_background_color"];
				$description_font_size = $settings["description_font_size"];
			}
			 
		?>


		<style>
			.post_title{
				color:<?= $title_color??"" ?>;
				font-style: <?= $title_font_style??"" ?>;
				font-weight: <?= $title_font_style??"" ?>;
				font-size:<?= isset($title_font_size)?$title_font_size."px":"" ?>;
				background-color:<?= $title_bg_color ??"" ?>;
			}
			.post_description{
				color:<?= $description_color??"" ?>;
				font-style: <?= $description_font_style??"" ?>;
				font-weight: <?= $description_font_style??"" ?>;
				font-size:<?= isset($description_font_size)?$description_font_size."px":"" ?>;
				background-color:<?= $description_bg_color ??"" ?>;
			}
		</style>

		<div class="row justify-content-center p-0 m-0 align-items-center mt-3" style="min-height: 80vh;">
			<div class="col-md-8 col-sm-10">
			<h1 class="border-start border-5 bg-secodary  shadow px-3 py-3 rounded mb-3">THEME SETTING</h1>
			<?= $_SESSION['msg']?? "" ?>
			<form action="database/user/user-process.php" method="POST" class="shadow my-3 p-sm-3 p-2 rounded" enctype="multipart/form-data">
				<input type="hidden" name="is_theme_set" value="<?= $is_theme_set  ?>">
				<input type="hidden" name="user_id" value="<?= $user_data['user_id']?>">
				<div class="d-flex justify-content-end">
					<div class="form-check form-switch  mb-3">
					  	<input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckChecked" <?= ($is_active == 'Active')?"checked":"" ?> name="theme_active">
						<label class="form-check-label" for="flexSwitchCheckChecked">Active Theme</label>
					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<b class="border-start border-3 bg-secodary px-2">TITLE PREVIEW</b>
						<p class="border p-2 my-2 post_title" id="title">
							Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae, libero?Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae, libero?
						</p>
					</div>
				</div>
				
				<h4 class="border-start border-3 bg-secodary px-2 mt-3">POST TITLE SETTING</h4>
				<div class="row">
					<div class="col-lg-6">
						<div class="form-floating">
						  <input type="color" class="form-control" name="title_color" id="floatingInput" placeholder="" onchange="setting(this,'color','title')" value="<?= $settings['title_color']??""; ?>" >
						  <label for="floatingInput">Post Title Color</label>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="form-floating mb-3">
							<select name="title_font_style" onchange="setting(this,'style','title')" class="form-select" aria-label="Default select example">
								<option value="" >Select Font Style</option>
								<option value="normal" <?= (isset($settings['title_font_style']) && $settings['title_font_style']=='normal')?'selected':''  ?> >Normal</option>
								<option value="italic" <?= (isset($settings['title_font_style']) && $settings['title_font_style']=='italic')?'selected':''  ?>>
							 		Italic
								</option>
							  <option value="bold"  <?= (isset($settings['title_font_style']) && $settings['title_font_style']=='bold')?'selected':''  ?>>Bold</option>
							</select>
						  <label for="floatingInput">Title Font Style</label>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-6">
						<div class="form-floating">
						  <input type="color" class="form-control" name="title_background_color"  onchange="setting(this,'bg_color','title')"  id="floatingInput" placeholder="" value="<?= $settings['title_background_color']??''; ?>">
						  <label for="floatingInput">Post Title Background Color</label>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="form-floating mb-3">
							<select name="title_font_size" class="form-select" aria-label="Default select example"  onchange="setting(this,'size','title')" >
							  <option value="">Select Font Size</option>
							  <?php 
							  	for ($i=12; $i <= 50; $i+=2) { 
							  ?>
							  <option value="<?= $i ?>" <?= (isset($settings['title_font_size']) && $settings['title_font_size']== $i)?'selected':''  ?>> <?= $i ?>px</option>
							 <?php } ?>
							</select>
						  <label for="floatingInput">Title Font Size</label>
						</div>
					</div>
				</div>
				<hr>
				<div class="row">
					<div class="col-12">
						<b class="border-start border-3 bg-secodary px-2">DESCRIPTION PREVIEW</b>
						<p class="border p-2 my-2 post_description" id="description">
							Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae, libero?Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae, libero?
						</p>
					</div>
				</div>
				<h4 class="border-start border-3 bg-secodary px-2">POST DESCRIPTION SETTING</h4>
				<div class="row">
					<div class="col-lg-6">
						<div class="form-floating">
						  <input type="color" class="form-control" onchange="setting(this,'color','description')"  name="description_color" id="floatingInput" placeholder="" value="<?= $settings['description_color']??""; ?>">
						  <label for="floatingInput">Post Description Color</label>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="form-floating mb-3">
							<select name="description_font_style" onchange="setting(this,'style','description')" class="form-select" aria-label="Default select example">
								<option value="" >Select Font Style</option>
								<option value="normal"  <?= (isset($settings['description_font_style']) && $settings['description_font_style']=='normal')?'selected':''  ?> >Normal</option>
								<option value="italic" <?= (isset($settings['description_font_style']) && $settings['description_font_style']=='italic')?'selected':''  ?>>
							 		Italic
								</option>
							  <option value="bold"  <?= (isset($settings['description_font_style']) && $settings['description_font_style']=='bold')?'selected':''  ?>>Bold</option>
							</select>
						  <label for="floatingInput">Description Font Style</label>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-6">
						<div class="form-floating">
						  <input type="color" class="form-control" name="description_background_color" onchange="setting(this,'bg_color','description')" id="floatingInput" placeholder="" value="<?= $settings['description_background_color']??''; ?>">
						  <label for="floatingInput">Post Description Background Color</label>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="form-floating mb-3">
							<select name="description_font_size"  onchange="setting(this,'size','description')"  class="form-select" aria-label="Default select example">
							  <option value="">Select Font Size</option>
							  <?php 
							  	for ($i=12; $i <= 50; $i+=2) { 
							  ?>
							  <option value="<?= $i ?>" <?= (isset($settings['description_font_size']) && $settings['description_font_size']==$i)?'selected':''  ?>> <?= $i ?>px</option>
							 <?php } ?>
							</select>
						  <label for="floatingInput">Description Font Size</label>
						</div>
					</div>
				</div>
				<div class="row justify-content-end">
					<div class="col-md-3 col-sm-6 mb-2">
						
					</div>
					<div class="col-md-3 col-sm-6">
						<input type="Submit" name="theme_setting" value="Save Setting" class="form-control btn btn-primary">
					</div>
				</div>
			</form>
			<?php 
				session_destroy();
			?>
			</div>
		</div>
	</div>
	<script>
		function setting(obj,property,part){
			if (property == "color") {
				if (part == "description") {
					document.getElementById('description').style.color = obj.value;
				}
				else if(part == "title"){
					document.getElementById('title').style.color = obj.value;
				}
			}
			if (property == "bg_color") {
				if (part == "description") {
					document.getElementById('description').style.backgroundColor = obj.value;
				}
				else if(part == "title"){
					document.getElementById('title').style.backgroundColor = obj.value;
				}
			}
			if (property == "size") {
				if (part == "description") {
					document.getElementById('description').style.fontSize = (obj.value+"px");
				}
				else if(part == "title"){
					document.getElementById('title').style.fontSize = (obj.value+"px");
				}
			}
			if (property == "style") {
				if (part == "description") {
					if ((obj.value) == "bold") {
						document.getElementById('description').style.fontWeight = (obj.value);
						document.getElementById('description').style.fontStyle = "normal";
					}else{
						document.getElementById('description').style.fontWeight = "normal";
						document.getElementById('description').style.fontStyle = (obj.value);

					}
				}
				else if(part == "title"){
					if ((obj.value) == "bold") {
						document.getElementById('title').style.fontWeight = (obj.value);
						document.getElementById('title').style.fontStyle = "normal";
					}else{
						document.getElementById('title').style.fontWeight = "normal";
						document.getElementById('title').style.fontStyle = (obj.value);

					}
				}
			}
		}
	</script>
<?php 
	include("assets/user/user-footer.php");
?>